package com.autoclick;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.List;

public class SlotsActivity extends Activity {
    private LinearLayout list;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        Slots.ensure(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        int p = Ui.dp(this, 16);
        root.setPadding(p, Ui.dp(this, 24), p, p);
        root.addView(Ui.text(this, "Auto clicks", 24, Ui.TEXT, true));
        root.addView(Ui.desc(this, "Até 5. Equipe um e dê play pelo botão flutuante. Cada um tem seus próprios ajustes."));

        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        root.addView(sv);

        root.addView(Ui.button(this, "+ Novo (Fortnite mobile)", Ui.ACCENT, v -> add("fn")));
        root.addView(Ui.button(this, "+ Novo (xCloud)", Ui.ACCENT, v -> add("xc")));
        root.addView(Ui.button(this, "Restaurar originais", Ui.DARK, v -> {
            if (!Slots.restoreOriginals(this)) toast("Sem espaço: exclua um auto click para recriar o original");
            render();
        }));
        setContentView(root);
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void add(String kind) {
        if (!Slots.add(this, kind, false)) toast("Limite de 5 auto clicks");
        render();
    }

    private void render() {
        list.removeAllViews();
        List<JSONObject> l = Slots.load(this);
        String eq = Slots.equippedId(this);
        if (l.isEmpty()) list.addView(Ui.desc(this, "Nenhum auto click. Crie um ou restaure os originais."));
        for (JSONObject o : l) {
            final String id = o.optString("id");
            final String nm = o.optString("name");
            boolean on = id.equals(eq);
            LinearLayout c = Ui.card(this);
            c.addView(Ui.text(this, nm + (on ? "  ✓ equipado" : ""), 17, on ? Ui.OK : Ui.TEXT, true));
            c.addView(Ui.desc(this, ("xc".equals(o.optString("kind")) ? "xCloud (Xbox)" : "Fortnite mobile")
                    + " • máx. " + o.optInt("maxmin", 30) + " min"));
            if (!on) c.addView(Ui.button(this, "Equipar", Ui.ACCENT, v -> { Slots.equip(this, o); render(); }));
            c.addView(Ui.button(this, "Editar", Ui.DARK,
                    v -> startActivity(new Intent(this, SlotEditActivity.class).putExtra("id", id))));
            c.addView(Ui.button(this, "Excluir", Ui.DANGER, v -> new AlertDialog.Builder(this)
                    .setTitle("Excluir \"" + nm + "\"?")
                    .setMessage("Você pode restaurar os originais depois em Restaurar originais.")
                    .setPositiveButton("Excluir", (d, w) -> { Slots.remove(this, id); render(); })
                    .setNegativeButton("Cancelar", null)
                    .show()));
            list.addView(c);
        }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
