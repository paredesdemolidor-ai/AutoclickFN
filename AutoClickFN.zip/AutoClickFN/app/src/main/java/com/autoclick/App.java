package com.autoclick;

import android.app.Application;

import java.io.PrintWriter;
import java.io.StringWriter;

public class App extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        I18n.init(this);
        final Thread.UncaughtExceptionHandler prev = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((t, e) -> {
            try {
                StringWriter sw = new StringWriter();
                e.printStackTrace(new PrintWriter(sw));
                String st = sw.toString();
                getSharedPreferences("cfg", MODE_PRIVATE).edit()
                        .putString("lastcrash", new java.util.Date() + "\n" + st.substring(0, Math.min(1500, st.length())))
                        .commit();
            } catch (Throwable ignored) {}
            if (prev != null) prev.uncaughtException(t, e);
        });
    }
}
