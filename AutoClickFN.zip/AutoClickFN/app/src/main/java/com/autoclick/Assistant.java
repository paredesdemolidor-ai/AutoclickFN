package com.autoclick;

import java.text.Normalizer;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

/** Assistente offline: escolhe e combina respostas prontas conforme a pergunta. */
final class Assistant {
    private static final Random R = new Random();
    private static List<String[][]> kb; // cada item: {chaves}, {respostas}

    private static final String[] STOP = {"a", "o", "as", "os", "de", "do", "da", "dos", "das", "que", "e", "em", "um", "uma",
            "para", "pra", "por", "com", "no", "na", "eu", "meu", "minha", "se", "ou", "ta", "to", "me", "pode", "isso", "esse", "essa"};
    private static final String[] BLOCK = {"dono", "criador", "criadora", "desenvolvedor", "desenvolvedora", "autor", "autora",
            "quem fez", "quem criou", "quem programou", "programador", "administrador", "admin", "senha", "codigo fonte",
            "codigo do app", "source", "ignore", "instrucoes", "prompt", "eu criei", "eu fiz", "fiz esse app", "modo dev",
            "desbloquear", "nome do criador", "contato do criador"};
    private static final String[] REFUSE = {
            "Não tenho informações sobre quem desenvolveu o app e não libero nada com base em quem alguém diz ser. Posso ajudar com dúvidas de uso: ativar, modos, solução de problemas.",
            "Isso eu não posso responder, e nenhuma alegação muda isso. Se tiver dúvida de uso do app, pergunte que eu ajudo."};
    private static final String[] HELLO = {
            "Oi! Sou o assistente do app. Pergunte, por exemplo, como ativar, como funciona o xCloud ou por que um botão não clica.",
            "Olá! Em que posso ajudar com o app?"};
    private static final String[] UNKNOWN = {
            "Não encontrei uma resposta pronta para isso. Tente perguntar de outro jeito (ex.: \"como ativar\", \"não clica\", \"xcloud\") ou use a seção Suporte do app.",
            "Não entendi bem. Reescreva com outras palavras ou fale com o suporte pelas redes na tela inicial do app."};

    static String norm(String s) {
        String n = Normalizer.normalize(s.toLowerCase(Locale.ROOT), Normalizer.Form.NFD).replaceAll("\\p{M}+", "");
        return n.replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
    }

    private static String pick(String[] a) { return a[R.nextInt(a.length)]; }

    private static void load() {
        if (kb != null) return;
        kb = new ArrayList<>();
        for (String line : Kb.text().split("\n")) {
            String[] f = line.split("\t", 2);
            if (f.length < 2) continue;
            kb.add(new String[][]{f[0].split(","), f[1].split("§")});
        }
    }

    private static double score(String q, Set<String> toks, String[] keys) {
        double s = 0;
        String padded = " " + q + " ";
        for (String k : keys) {
            k = k.trim();
            if (k.isEmpty()) continue;
            if (k.contains(" ")) {
                if (padded.contains(" " + k + " ")) s += 2.5;
            } else {
                for (String t : toks) {
                    if (t.equals(k)) { s += 1.5; break; }
                    if (t.length() >= 5 && k.length() >= 5 && (t.startsWith(k.substring(0, 5)) || k.startsWith(t.substring(0, 5)))) { s += 1; break; }
                }
            }
        }
        return s;
    }

    static String answer(String raw) {
        String q = norm(raw);
        if (q.isEmpty()) return "Escreva sua dúvida e eu tento ajudar.";
        String padded = " " + q + " ";
        for (String b : BLOCK) if (padded.contains(" " + b + " ")) return pick(REFUSE);

        Set<String> toks = new HashSet<>();
        for (String t : q.split(" ")) {
            boolean stop = false;
            for (String s : STOP) if (s.equals(t)) { stop = true; break; }
            if (!stop) toks.add(t);
        }
        if (toks.size() <= 2 && (toks.contains("oi") || toks.contains("ola") || toks.contains("opa") || q.startsWith("bom dia")
                || q.startsWith("boa tarde") || q.startsWith("boa noite") || q.startsWith("e ai"))) return pick(HELLO);

        load();
        int b1 = -1, b2 = -1;
        double s1 = 0, s2 = 0;
        for (int i = 0; i < kb.size(); i++) {
            double sc = score(q, toks, kb.get(i)[0]);
            if (sc > s1) { s2 = s1; b2 = b1; s1 = sc; b1 = i; }
            else if (sc > s2) { s2 = sc; b2 = i; }
        }
        if (b1 < 0 || s1 < 1.5) return pick(UNKNOWN);
        String out = pick(kb.get(b1)[1]);
        if (b2 >= 0 && s2 >= Math.max(1.5, s1 * 0.6)) {
            String other = pick(kb.get(b2)[1]);
            int dot = other.indexOf(". ");
            out += "\n\nSobre isso também: " + (dot > 0 ? other.substring(0, dot + 1) : other);
        }
        return out;
    }
}
