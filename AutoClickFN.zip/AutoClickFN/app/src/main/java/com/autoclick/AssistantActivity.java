package com.autoclick;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class AssistantActivity extends Activity {
    private LinearLayout list;
    private ScrollView sv;
    private EditText in;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        int p = Ui.dp(this, 16);
        root.setPadding(p, Ui.dp(this, 24), p, p);

        root.addView(Ui.text(this, "Assistente", 22, Ui.TEXT, true));
        TextView sub = Ui.text(this, "Offline • respostas prontas sobre o uso do app", 12, Ui.MUTED, false);
        sub.setPadding(0, 0, 0, Ui.dp(this, 8));
        root.addView(sub);

        sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        root.addView(sv);

        bubble("Oi! Pergunte sobre o app. Toque em uma sugestão ou escreva a sua dúvida.", false);
        String[] sug = {"Como ativar o serviço?", "Como funciona o xCloud?", "Um botão não é clicado", "Como desligar tudo?"};
        for (String s : sug) {
            Button c = Ui.button(this, s, Ui.DARK, v -> send(s));
            list.addView(c);
        }

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        in = new EditText(this);
        in.setHint("Escreva sua dúvida");
        in.setHintTextColor(Ui.MUTED);
        in.setTextColor(Ui.TEXT);
        in.setSingleLine(true);
        int pd = Ui.dp(this, 12);
        in.setPadding(pd, pd, pd, pd);
        in.setBackground(Ui.shape(this, Ui.CARD, 14, 0, 0));
        in.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        Button send = Ui.button(this, "Enviar", Ui.ACCENT, v -> {
            String q = in.getText().toString().trim();
            if (!q.isEmpty()) { in.setText(""); send(q); }
        });
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 90), Ui.dp(this, 46));
        lp.setMargins(Ui.dp(this, 8), 0, 0, 0);
        send.setLayoutParams(lp);
        row.addView(in);
        row.addView(send);
        root.addView(row);
        setContentView(root);
    }

    private void send(String q) {
        bubble(q, true);
        bubble(Assistant.answer(q), false);
        sv.post(() -> sv.fullScroll(ScrollView.FOCUS_DOWN));
    }

    private void bubble(String text, boolean user) {
        TextView t = Ui.text(this, text, 14, Ui.TEXT, false);
        int pd = Ui.dp(this, 12);
        t.setPadding(pd, pd, pd, pd);
        t.setBackground(Ui.shape(this, user ? Ui.ACCENT : Ui.CARD, 16, 0, 0));
        t.setMaxWidth((int) (getResources().getDisplayMetrics().widthPixels * 0.82f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.gravity = user ? Gravity.END : Gravity.START;
        lp.setMargins(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
        t.setLayoutParams(lp);
        list.addView(t);
    }
}
