package com.autoclick;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.view.View;

import java.util.Random;

/** Fundo escuro animado com brilhos e faiscas. */
public class GlowView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float[][] sparks = new float[36][5];
    private final long t0 = System.nanoTime();
    private float intensity = 1f;

    public GlowView(Context c) {
        super(c);
        Random r = new Random();
        for (float[] s : sparks) {
            s[0] = r.nextFloat();
            s[1] = r.nextFloat();
            s[2] = 0.02f + r.nextFloat() * 0.06f;
            s[3] = 1.2f + r.nextFloat() * 2.8f;
            s[4] = r.nextFloat() * 6.28f;
        }
    }

    void setIntensity(float v) { intensity = v; }

    private static int alpha(int color, float a) {
        int al = Math.max(0, Math.min(255, (int) (a * 255)));
        return (al << 24) | (color & 0x00FFFFFF);
    }

    private void glow(Canvas c, float x, float y, float rad, int color, float a) {
        paint.setShader(new RadialGradient(x, y, rad, new int[]{alpha(color, a), alpha(color, 0f)}, null, Shader.TileMode.CLAMP));
        c.drawCircle(x, y, rad, paint);
        paint.setShader(null);
    }

    @Override
    protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight();
        float t = (System.nanoTime() - t0) / 1e9f;
        c.drawColor(0xFF05060D);
        float big = Math.max(w, h);
        glow(c, w * (0.28f + 0.12f * (float) Math.sin(t * 0.7)), h * (0.5f + 0.1f * (float) Math.cos(t * 0.5)),
                big * 0.6f, Ui.ACCENT, (0.45f + 0.15f * (float) Math.sin(t * 1.3)) * intensity);
        glow(c, w * (0.78f + 0.1f * (float) Math.cos(t * 0.6)), h * (0.35f + 0.1f * (float) Math.sin(t * 0.8)),
                big * 0.5f, 0xFF00E5FF, (0.30f + 0.10f * (float) Math.cos(t * 1.1)) * intensity);
        float d = getResources().getDisplayMetrics().density;
        paint.setColor(0xFFFFFFFF);
        for (float[] s : sparks) {
            float y = (s[1] - s[2] * t) % 1f;
            if (y < 0) y += 1f;
            float tw = 0.5f + 0.5f * (float) Math.sin(t * 2f + s[4]);
            paint.setAlpha((int) (255 * tw * 0.9f * Math.min(1f, intensity)));
            c.drawCircle(s[0] * w, y * h, s[3] * d * 0.5f, paint);
        }
        postInvalidateOnAnimation();
    }
}
