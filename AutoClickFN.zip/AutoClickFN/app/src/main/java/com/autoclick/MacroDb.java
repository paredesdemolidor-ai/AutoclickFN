package com.autoclick;

import org.json.JSONObject;

import java.util.Locale;

/** Banco offline de jogos e objetivos: monta um macro inicial a partir do nome do jogo e do que voce quer. */
final class MacroDb {
    static final class Game {
        final String name, warn;
        final String[] aliases, play;
        Game(String name, String[] aliases, String[] play, String warn) {
            this.name = name; this.aliases = aliases; this.play = play; this.warn = warn;
        }
    }

    private static final String SHOOTER = "Jogo competitivo com anti-cheat: automação pode causar banimento. Evite modos ranqueados e use por sua conta e risco.";

    static final Game[] GAMES = {
            new Game("Call of Duty Mobile", new String[]{"cod", "codm", "call of duty", "call of duty mobile"},
                    new String[]{"MULTIJOGADOR", "PARTIDA", "BATTLE ROYALE"}, SHOOTER),
            new Game("Free Fire", new String[]{"free fire", "freefire", "ff"},
                    new String[]{"COMEÇAR", "PARTIDA"}, SHOOTER),
            new Game("PUBG Mobile", new String[]{"pubg", "pubg mobile"},
                    new String[]{"INICIAR", "PARTIDA"}, SHOOTER),
            new Game("Brawl Stars", new String[]{"brawl stars", "brawl"},
                    new String[]{"PRONTO", "PREPARAR"}, ""),
            new Game("Clash Royale", new String[]{"clash royale", "clash"},
                    new String[]{"BATALHA", "BATTLE"}, ""),
            new Game("Roblox", new String[]{"roblox"}, new String[]{"JOGAR", "PLAY"}, ""),
            new Game("Minecraft", new String[]{"minecraft"}, new String[]{"JOGAR", "PLAY"}, ""),
    };

    private static String L(String lang, String pt, String en, String es) {
        return "en".equals(lang) ? en : "es".equals(lang) ? es : pt;
    }

    private static boolean has(String t, String... keys) {
        for (String k : keys) if (t.contains(k)) return true;
        return false;
    }

    /** Preenche summary com o que foi montado e devolve o macro (JSON de slot). */
    static JSONObject generate(String gameIn, String goalIn, String extraIn, StringBuilder summary, String lang) {
        String g = Assistant.norm(gameIn), t = Assistant.norm(goalIn);
        Game hit = null;
        if (!g.isEmpty()) {
            for (Game x : GAMES)
                for (String a : x.aliases)
                    if (g.equals(a) || g.contains(a) || (g.length() >= 4 && a.contains(g))) hit = x;
        }
        boolean afk = has(t, "afk", "ocioso", "ociosidade", "parado", "inativ", "expuls", "nao cair", "idle", "inactiv", "no ser expulsado");
        boolean loop = has(t, "partida", "jogar", "loop", "repet", "farm", "automatic", "sozinho", "infinit", "xp", "match", "play", "repeat", "jugar", "repetir");
        boolean reward = has(t, "recompensa", "resgat", "colet", "claim", "bau", "missao", "reward", "collect", "recoger", "mision");
        boolean ads = has(t, "anuncio", "pular", "skip", "propaganda", "ads", "advert", "omitir");
        if (!afk && !loop && !reward && !ads) { loop = true; reward = true; ads = true; }

        StringBuilder rules = new StringBuilder();
        int extras = 0;
        for (String w : extraIn.split("[\n,;]")) {
            w = w.trim().toUpperCase(Locale.ROOT);
            if (!w.isEmpty()) { rules.append(w).append('\n'); extras++; }
        }
        if (reward) rules.append(L(lang, "RESGATAR|COLETAR|RECEBER|CLAIM|COLLECT", "CLAIM|COLLECT|RECEIVE|REDEEM", "RECLAMAR|RECOGER|RECIBIR|CANJEAR")).append('\n');
        if (ads) rules.append(L(lang, "PULAR|SKIP|FECHAR|CLOSE|AGORA NÃO|NÃO, OBRIGADO", "SKIP|CLOSE|NOT NOW|NO THANKS", "OMITIR|CERRAR|AHORA NO|NO, GRACIAS")).append('\n');
        if (loop) {
            rules.append(L(lang, "JOGAR NOVAMENTE|PLAY AGAIN|RETORNAR AO LOBBY|VOLTAR AO LOBBY", "PLAY AGAIN|RETURN TO LOBBY", "JUGAR DE NUEVO|VOLVER AL LOBBY")).append('\n');
            rules.append(L(lang, "CONTINUAR|CONTINUE|TOQUE PARA CONTINUAR|OK", "CONTINUE|TAP TO CONTINUE|OK", "CONTINUAR|TOCA PARA CONTINUAR|OK")).append('\n');
            StringBuilder play = new StringBuilder(L(lang, "JOGAR|INICIAR|PLAY|START", "PLAY|START", "JUGAR|INICIAR|EMPEZAR"));
            if (hit != null) for (String p : hit.play) play.append('|').append(p);
            rules.append(play).append('\n');
        }

        String name = hit != null ? hit.name : (gameIn.trim().isEmpty() ? "Macro livre" : gameIn.trim());
        summary.append(hit != null ? "Jogo reconhecido: " + hit.name + "." : "Jogo fora do banco: usei regras genéricas.");
        summary.append("\nO macro vai: ");
        StringBuilder what = new StringBuilder();
        if (reward) what.append("resgatar recompensas, ");
        if (ads) what.append("pular anúncios e avisos, ");
        if (loop) what.append("repetir partidas (jogar novamente / retornar ao lobby / jogar), ");
        if (afk) what.append("mexer o personagem para evitar inatividade, ");
        if (extras > 0) what.append("clicar nas suas " + extras + " palavras extras primeiro, ");
        if (what.length() > 2) summary.append(what.substring(0, what.length() - 2)).append('.');
        if (hit != null && !hit.warn.isEmpty()) summary.append("\n\nAtenção: ").append(hit.warn);
        summary.append("\n\nÉ um ponto de partida: teste e ajuste as regras e as palavras extras (o Diagnóstico mostra o que o app lê).");

        JSONObject o = Slots.template("custom", false);
        try {
            o.put("name", name + " (macro)");
            o.put("game", name);
            o.put("rules", rules.toString().trim());
            o.put("afk", afk);
            o.put("notes", "Objetivo: " + goalIn.trim());
        } catch (Exception ignored) {}
        return o;
    }
}
