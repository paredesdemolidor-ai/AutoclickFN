package com.autoclick;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.graphics.Typeface;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class DiagActivity extends Activity {
    private TextView tv;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        int p = Ui.dp(this, 16);
        root.setPadding(p, Ui.dp(this, 24), p, p);
        root.addView(Ui.header(this, "Diagnóstico"));
        TextView sub = Ui.text(this, "O que o app leu e decidiu. Copie e envie ao suporte se algo travar.", 12, Ui.MUTED, false);
        sub.setPadding(0, 0, 0, Ui.dp(this, 8));
        root.addView(sub);

        ScrollView sv = new ScrollView(this);
        sv.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        tv = Ui.text(this, "", 11, Ui.TEXT, false);
        tv.setTypeface(Typeface.MONOSPACE);
        tv.setTextIsSelectable(true);
        sv.addView(tv);
        root.addView(sv);

        root.addView(Ui.button(this, "Atualizar", Ui.ACCENT, v -> refresh()));
        root.addView(Ui.button(this, "Copiar", Ui.DARK, v -> {
            ClipboardManager cm = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);
            cm.setPrimaryClip(ClipData.newPlainText("diagnostico", fullText()));
            Toast.makeText(this, "Copiado", Toast.LENGTH_SHORT).show();
        }));
        root.addView(Ui.button(this, "Limpar", Ui.DANGER, v -> { ClickService.clearLog(); refresh(); }));
        setContentView(root);
        refresh();
    }

    private String fullText() {
        String c = getSharedPreferences("cfg", MODE_PRIVATE).getString("lastcrash", "");
        String log = ClickService.dumpLog();
        return (c.isEmpty() ? "" : "=== ÚLTIMO ERRO DO APP ===\n" + c + "\n\n=== REGISTRO ===\n") + log;
    }

    private void refresh() {
        String s = fullText();
        tv.setText(s.isEmpty() ? "(vazio) Inicie o auto click e volte aqui." : s);
    }
}
