package com.autoclick;

import android.app.NotificationManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/** Toque na notificacao: mostra a bolinha de novo, sem abrir nenhum app. */
public class RestoreReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent i) {
        if (ClickService.instance != null) ClickService.instance.setOverlayVisible(true);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        if (nm != null) nm.cancel(7);
    }
}
