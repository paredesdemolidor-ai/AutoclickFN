package com.autoclick;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.InputStream;

public class MainActivity extends Activity {
    private static final String YT = "https://www.youtube.com/@naoseicomocolocaonome_dasilva";
    private static final String TT = "https://www.tiktok.com/@palhaco.do.bem";
    private static final int REQ_BG = 21;
    private static final int[] COLORS = {0xFF7C4DFF, 0xFF00E5FF, 0xFF3DDC84, 0xFFFF4081, 0xFFFF9100, 0xFFE5484D};

    private SharedPreferences sp;
    private EditText nick, hold;
    private TextView nickAuto, statusTv, equippedTv;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);
        Ui.ACCENT = sp.getInt("accent", 0xFF7C4DFF);
        Slots.ensure(this);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        if (Build.VERSION.SDK_INT >= 33 && !sp.getBoolean("askedNotif", false)
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            sp.edit().putBoolean("askedNotif", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
        }

        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 18);
        root.setPadding(p, Ui.dp(this, 24), p, p);
        sv.addView(root);

        // ---- capa animada ----
        FrameLayout banner = new FrameLayout(this);
        banner.setBackground(Ui.shape(this, 0xFF05060D, 22, 0, 0));
        banner.setClipToOutline(true);
        banner.addView(new GlowView(this), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout tl = new LinearLayout(this);
        tl.setOrientation(LinearLayout.VERTICAL);
        tl.setGravity(Gravity.BOTTOM);
        tl.setPadding(Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 18), Ui.dp(this, 18));
        TextView title = Ui.text(this, "NexMacro", 30, Ui.TEXT, true);
        title.setLetterSpacing(0.05f);
        title.setShadowLayer(18f, 0, 0, Ui.CYAN);
        tl.addView(title);
        tl.addView(Ui.text(this, greeting() + "! Macros de toque para jogos e apps", 13, Ui.MUTED, false));
        banner.addView(tl, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 170));
        blp.setMargins(0, 0, 0, Ui.dp(this, 14));
        root.addView(banner, blp);

        // ---- status ----
        LinearLayout st = Ui.card(this);
        statusTv = Ui.text(this, "", 17, Ui.TEXT, true);
        st.addView(statusTv);
        st.addView(Ui.desc(this, "Ative o serviço de acessibilidade para o app tocar na tela e ler botões. Tudo acontece no seu aparelho."));
        st.addView(Ui.button(this, "Abrir acessibilidade", Ui.ACCENT,
                v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(st);

        // ---- auto click equipado ----
        root.addView(Ui.section(this, "Auto clicks"));
        LinearLayout ac = Ui.card(this);
        ac.addView(Ui.text(this, "Equipado agora", 13, Ui.MUTED, false));
        equippedTv = Ui.text(this, "", 20, Ui.TEXT, true);
        ac.addView(equippedTv);
        ac.addView(Ui.desc(this, "Você tem até 5 auto clicks, cada um com nome, tempo, palavras extras e anotações. Equipe um e dê play pela bolinha flutuante."));
        ac.addView(Ui.button(this, "Gerenciar auto clicks", Ui.ACCENT,
                v -> startActivity(new Intent(this, SlotsActivity.class))));
        root.addView(ac);

        // ---- ajustes ----
        root.addView(Ui.section(this, "Ajustes"));
        LinearLayout c1 = Ui.card(this);
        c1.addView(Ui.text(this, "Seu nick no Fortnite", 16, Ui.TEXT, true));
        c1.addView(Ui.desc(this, "Usado para não confundir você com um companheiro ao olhar a barra do time. Deixe vazio para ler sozinho no lobby."));
        nick = Ui.field(this, "Ex.: SeuNick", false);
        nick.setText(sp.getString("nick", ""));
        c1.addView(nick);
        nickAuto = Ui.desc(this, "");
        c1.addView(nickAuto);
        root.addView(c1);

        // ---- bolinha ----
        root.addView(Ui.section(this, "Bolinha flutuante"));
        LinearLayout c2 = Ui.card(this);
        c2.addView(Ui.text(this, "Menu em roda", 16, Ui.TEXT, true));
        c2.addView(Ui.desc(this, "Toque na bolinha para abrir a roda: Play/Stop, próximo auto click, abrir o app, ocultar e desligar. Arraste para mover e solte na lixeira para ocultar (uma notificação traz de volta, sem abrir o app)."));
        c2.addView(Ui.desc(this, "Segurar para abrir (segundos, 0 = só tocar):"));
        hold = Ui.field(this, "0", false);
        hold.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        hold.setText(String.valueOf(sp.getFloat("holdsec", 0f)));
        c2.addView(hold);
        c2.addView(Ui.button(this, "Mostrar bolinha", Ui.DARK, v -> {
            if (ClickService.instance != null) ClickService.instance.setOverlayVisible(true);
            else toast("Ative o serviço em Acessibilidade primeiro");
        }));
        c2.addView(Ui.button(this, "Esconder bolinha", Ui.DARK, v -> {
            if (ClickService.instance != null) ClickService.instance.setOverlayVisible(false);
            else toast("O serviço não está ativo");
        }));
        root.addView(c2);

        // ---- personalizacao ----
        root.addView(Ui.section(this, "Personalização"));
        LinearLayout c3 = Ui.card(this);
        c3.addView(Ui.text(this, "Cor dos botões", 16, Ui.TEXT, true));
        LinearLayout colors = new LinearLayout(this);
        colors.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < COLORS.length; i++) {
            final int col = COLORS[i];
            View dot = new View(this);
            dot.setBackground(Ui.shape(this, col, 20, Ui.TEXT, col == Ui.ACCENT ? 3 : 0));
            LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40));
            dl.setMargins(0, Ui.dp(this, 10), Ui.dp(this, 10), 0);
            dot.setLayoutParams(dl);
            dot.setOnClickListener(v -> { sp.edit().putInt("accent", col).apply(); recreate(); });
            Ui.pressable(dot);
            colors.addView(dot);
        }
        c3.addView(colors);
        c3.addView(Ui.desc(this, "Foto de fundo do app:"));
        c3.addView(Ui.button(this, "Escolher foto", Ui.DARK, v -> {
            Intent in = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            in.addCategory(Intent.CATEGORY_OPENABLE);
            in.setType("image/*");
            startActivityForResult(in, REQ_BG);
        }));
        c3.addView(Ui.button(this, "Remover foto", Ui.DARK, v -> {
            sp.edit().remove("bg").apply();
            recreate();
        }));
        root.addView(c3);

        // ---- otimizacao e desligar ----
        root.addView(Ui.section(this, "Sistema"));
        LinearLayout c4 = Ui.card(this);
        c4.addView(Ui.text(this, "Otimização", 16, Ui.TEXT, true));
        c4.addView(Ui.desc(this, "Para rodar liso: feche outros apps, deixe a bateria sem restrição para o app, use a velocidade Econômico em sessões longas e mantenha o jogo em tela cheia e deitado."));
        c4.addView(Ui.button(this, "Abrir ajustes de bateria", Ui.DARK, v -> {
            try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
            catch (Exception e) { toast("Abra Configurações > Bateria manualmente"); }
        }));
        root.addView(c4);

        LinearLayout c5 = Ui.card(this);
        c5.addView(Ui.text(this, "Desligar tudo", 16, Ui.TEXT, true));
        c5.addView(Ui.desc(this, "Para o loop, remove a bolinha e desativa o serviço, sem desinstalar. Para usar de novo, ative em Acessibilidade."));
        c5.addView(Ui.button(this, "DESLIGAR TUDO", Ui.DANGER, v -> {
            if (ClickService.instance != null) {
                ClickService.instance.shutdown();
                toast("Desligado. Para usar de novo, ative em Acessibilidade.");
                onResume();
            } else toast("O serviço já está desligado");
        }));
        root.addView(c5);

        // ---- ajuda ----
        root.addView(Ui.section(this, "Ajuda"));
        LinearLayout c6 = Ui.card(this);
        c6.addView(Ui.text(this, "Assistente e diagnóstico", 16, Ui.TEXT, true));
        c6.addView(Ui.desc(this, "O assistente tira dúvidas de uso. O diagnóstico mostra o que o app leu na tela e decidiu, útil quando algo trava."));
        c6.addView(Ui.button(this, "Conversar com o assistente", Ui.ACCENT,
                v -> startActivity(new Intent(this, AssistantActivity.class))));
        c6.addView(Ui.button(this, "Abrir diagnóstico", Ui.DARK,
                v -> startActivity(new Intent(this, DiagActivity.class))));
        root.addView(c6);

        LinearLayout c7 = Ui.card(this);
        c7.addView(Ui.text(this, "Créditos e suporte", 16, Ui.TEXT, true));
        c7.addView(Ui.desc(this, "Teve algum problema ou quer acompanhar as novidades? Fale pelas redes:"));
        c7.addView(Ui.button(this, "YouTube", 0xFFC4302B, v -> open(YT)));
        c7.addView(Ui.button(this, "TikTok", 0xFF111111, v -> open(TT)));
        root.addView(c7);

        TextView foot = Ui.text(this, "Sem coleta de dados • use por sua conta e risco: jogos podem punir automação.",
                12, Ui.MUTED, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 24));
        root.addView(foot);

        // ---- fundo (cor ou foto) ----
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Ui.BG);
        String bg = sp.getString("bg", "");
        if (!bg.isEmpty()) {
            try {
                ImageView iv = new ImageView(this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setImageBitmap(decode(Uri.parse(bg)));
                frame.addView(iv, new FrameLayout.LayoutParams(-1, -1));
                View dim = new View(this);
                dim.setBackgroundColor(0xCC05060D);
                frame.addView(dim, new FrameLayout.LayoutParams(-1, -1));
            } catch (Exception e) {
                sp.edit().remove("bg").apply();
            }
        }
        frame.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);

        // animacao de entrada
        for (int i = 0; i < root.getChildCount(); i++) {
            View v = root.getChildAt(i);
            v.setAlpha(0f);
            v.setTranslationY(Ui.dp(this, 24));
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 55L).setDuration(380).start();
        }
    }

    private Bitmap decode(Uri u) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
        int sample = 1;
        while (o.outWidth / sample > 1600) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        try (InputStream in = getContentResolver().openInputStream(u)) { return BitmapFactory.decodeStream(in, null, o2); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_BG && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) {}
            sp.edit().putString("bg", u.toString()).apply();
            recreate();
        }
    }

    private String greeting() {
        int h = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        return h >= 5 && h < 12 ? "Bom dia" : h >= 12 && h < 18 ? "Boa tarde" : "Boa noite";
    }

    private void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { toast("Não foi possível abrir o link"); }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override
    protected void onResume() {
        super.onResume();
        boolean on = ClickService.instance != null;
        statusTv.setText(on ? "● Serviço ativo" : "● Serviço desativado");
        statusTv.setTextColor(on ? Ui.OK : Ui.DANGER);
        JSONObject e = Slots.equipped(this);
        equippedTv.setText(e == null ? "(nenhum)" : e.optString("name"));
        String a = sp.getString("nick_auto", "");
        nickAuto.setText(a.isEmpty() ? "Nick lido automaticamente: (ainda não)" : "Nick lido automaticamente: " + a);
    }

    @Override
    protected void onPause() {
        super.onPause();
        float hs = 0f;
        try { hs = Math.max(0f, Math.min(10f, Float.parseFloat(hold.getText().toString().trim().replace(',', '.')))); }
        catch (Exception ignored) {}
        sp.edit().putString("nick", nick.getText().toString().trim()).putFloat("holdsec", hs).apply();
    }
}
