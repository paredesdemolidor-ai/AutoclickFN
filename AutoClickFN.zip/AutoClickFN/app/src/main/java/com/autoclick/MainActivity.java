package com.autoclick;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final String YT = "https://www.youtube.com/@naoseicomocolocaonome_dasilva";
    private static final String TT = "https://www.tiktok.com/@palhaco.do.bem";

    private SharedPreferences sp;
    private String cur;
    private EditText nick, extra;
    private TextView nickAuto, statusTv;
    private LinearLayout cardFn, cardXc;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);
        cur = sp.getString("mode", "fn");

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 18);
        root.setPadding(p, Ui.dp(this, 28), p, p);
        sv.addView(root);

        root.addView(Ui.text(this, "AutoClick FN", 28, Ui.TEXT, true));
        TextView sub = Ui.text(this, "Automação 100% offline para Fortnite e xCloud", 14, Ui.MUTED, false);
        sub.setPadding(0, 0, 0, Ui.dp(this, 16));
        root.addView(sub);

        // ---- status ----
        LinearLayout st = Ui.card(this);
        statusTv = Ui.text(this, "", 17, Ui.TEXT, true);
        st.addView(statusTv);
        st.addView(desc("Ative o serviço de acessibilidade do app para ele poder tocar na tela e ler botões. Tudo acontece no seu aparelho."));
        st.addView(Ui.button(this, "Abrir acessibilidade", Ui.ACCENT,
                v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        root.addView(st);

        // ---- modo ----
        root.addView(section("Modo de uso"));
        cardFn = modeCard("Fortnite mobile",
                "Entra na partida, se mexe para não ser expulso por inatividade, sai quando o time todo cai, coleta recompensas e começa outra.", "fn");
        cardXc = modeCard("xCloud (Xbox)",
                "Abre o Fortnite no app Xbox, passa pela fila e pelos anúncios, pula avisos e questionários, confere o modo Battle Royale e joga em loop.", "xc");
        root.addView(cardFn);
        root.addView(cardXc);

        // ---- nick ----
        root.addView(section("Ajustes"));
        LinearLayout c1 = Ui.card(this);
        c1.addView(Ui.text(this, "Seu nick no Fortnite", 16, Ui.TEXT, true));
        c1.addView(desc("Usado para não confundir você com um companheiro ao olhar a barra do time. Deixe vazio para ler sozinho no lobby."));
        nick = field("Ex.: SeuNick", false);
        nick.setText(sp.getString("nick", ""));
        c1.addView(nick);
        nickAuto = desc("");
        c1.addView(nickAuto);
        root.addView(c1);

        LinearLayout c2 = Ui.card(this);
        c2.addView(Ui.text(this, "Palavras extras para clicar", 16, Ui.TEXT, true));
        c2.addView(desc("Se um botão não for clicado, escreva o texto exato dele (uma palavra ou frase por linha). Vale para o modo escolhido."));
        extra = field("Ex.: ENTRAR NA FILA", true);
        extra.setText(sp.getString("extra_" + cur, ""));
        c2.addView(extra);
        root.addView(c2);

        // ---- controles ----
        root.addView(section("Controles"));
        LinearLayout c3 = Ui.card(this);
        c3.addView(Ui.text(this, "Botão flutuante", 16, Ui.TEXT, true));
        c3.addView(desc("Fica sobre o jogo: toque rápido inicia ou para, arraste para mover e o ✕ esconde."));
        c3.addView(Ui.button(this, "Mostrar botão flutuante", Ui.DARK, v -> {
            if (ClickService.instance != null) ClickService.instance.setOverlayVisible(true);
            else toast("Ative o serviço em Acessibilidade primeiro");
        }));
        c3.addView(Ui.button(this, "Esconder botão flutuante", Ui.DARK, v -> {
            if (ClickService.instance != null) ClickService.instance.setOverlayVisible(false);
            else toast("O serviço não está ativo");
        }));
        root.addView(c3);

        LinearLayout c4 = Ui.card(this);
        c4.addView(Ui.text(this, "Desligar tudo", 16, Ui.TEXT, true));
        c4.addView(desc("Para o loop, remove o botão e desativa o serviço, sem precisar desinstalar. Para usar de novo, ative em Acessibilidade."));
        c4.addView(Ui.button(this, "DESLIGAR TUDO", Ui.DANGER, v -> {
            if (ClickService.instance != null) {
                ClickService.instance.shutdown();
                toast("Desligado. Para usar de novo, ative em Acessibilidade.");
                onResume();
            } else toast("O serviço já está desligado");
        }));
        root.addView(c4);

        // ---- assistente ----
        root.addView(section("Ajuda"));
        LinearLayout c5 = Ui.card(this);
        c5.addView(Ui.text(this, "Assistente (offline)", 16, Ui.TEXT, true));
        c5.addView(desc("Tire dúvidas sobre o uso do app. Responde com respostas prontas, sem internet."));
        c5.addView(Ui.button(this, "Conversar com o assistente", Ui.ACCENT,
                v -> startActivity(new Intent(this, AssistantActivity.class))));
        root.addView(c5);

        LinearLayout c6 = Ui.card(this);
        c6.addView(Ui.text(this, "Suporte e comunidade", 16, Ui.TEXT, true));
        c6.addView(desc("Teve algum problema? Fale pelas redes:"));
        c6.addView(Ui.button(this, "YouTube", 0xFFC4302B, v -> open(YT)));
        c6.addView(Ui.button(this, "TikTok", 0xFF111111, v -> open(TT)));
        root.addView(c6);

        TextView foot = Ui.text(this, "Sem internet • sem coleta de dados • use por sua conta e risco: jogos podem punir automação.",
                12, Ui.MUTED, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 24));
        root.addView(foot);

        refreshModes();
        setContentView(sv);
    }

    private TextView desc(String s) {
        TextView t = Ui.text(this, s, 13, Ui.MUTED, false);
        t.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 4));
        return t;
    }

    private TextView section(String s) {
        TextView t = Ui.text(this, s.toUpperCase(), 12, Ui.CYAN, true);
        t.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 8));
        return t;
    }

    private LinearLayout modeCard(String title, String d, String id) {
        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this, title, 16, Ui.TEXT, true));
        c.addView(desc(d));
        c.setOnClickListener(v -> setMode(id));
        return c;
    }

    private EditText field(String hint, boolean multi) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setHintTextColor(Ui.MUTED);
        e.setTextColor(Ui.TEXT);
        e.setTextSize(14);
        int pd = Ui.dp(this, 12);
        e.setPadding(pd, pd, pd, pd);
        e.setBackground(Ui.shape(this, Ui.BG, 12, Ui.DARK, 1));
        if (multi) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            e.setMinLines(3);
            e.setGravity(Gravity.TOP);
        } else {
            e.setSingleLine(true);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, Ui.dp(this, 8), 0, 0);
        e.setLayoutParams(lp);
        return e;
    }

    private void setMode(String id) {
        sp.edit().putString("extra_" + cur, extra.getText().toString()).apply();
        cur = id;
        sp.edit().putString("mode", cur).apply();
        extra.setText(sp.getString("extra_" + cur, ""));
        refreshModes();
    }

    private void refreshModes() {
        cardFn.setBackground(Ui.shape(this, Ui.CARD, 18, Ui.ACCENT, cur.equals("fn") ? 2 : 0));
        cardXc.setBackground(Ui.shape(this, Ui.CARD, 18, Ui.ACCENT, cur.equals("xc") ? 2 : 0));
    }

    private void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { toast("Não foi possível abrir o link"); }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override
    protected void onResume() {
        super.onResume();
        boolean on = ClickService.instance != null;
        statusTv.setText(on ? "● Serviço ativo" : "● Serviço desativado");
        statusTv.setTextColor(on ? Ui.OK : Ui.DANGER);
        String a = sp.getString("nick_auto", "");
        nickAuto.setText(a.isEmpty() ? "Nick lido automaticamente: (ainda não)" : "Nick lido automaticamente: " + a);
    }

    @Override
    protected void onPause() {
        super.onPause();
        sp.edit().putString("mode", cur)
                .putString("nick", nick.getText().toString().trim())
                .putString("extra_" + cur, extra.getText().toString()).apply();
    }
}
