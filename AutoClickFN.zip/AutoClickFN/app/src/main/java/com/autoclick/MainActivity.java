package com.autoclick;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(48, 96, 48, 48);
        TextView t = new TextView(this);
        t.setTextSize(16);
        t.setText("1) Toque no botão abaixo, abra \"AutoClick FN\" e ative o serviço.\n\n"
                + "2) Um botão flutuante \"Iniciar\" aparecerá na tela.\n\n"
                + "3) Abra o Fortnite no lobby e toque em \"Iniciar\". Toque em \"Parar\" para encerrar.");
        Button bt = new Button(this);
        bt.setText("Abrir configurações de acessibilidade");
        bt.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));
        l.addView(t);
        l.addView(bt);
        setContentView(l);
    }
}
