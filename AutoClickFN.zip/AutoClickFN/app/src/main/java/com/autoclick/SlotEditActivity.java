package com.autoclick;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import org.json.JSONObject;

import java.util.List;

public class SlotEditActivity extends Activity {
    private List<JSONObject> all;
    private JSONObject o;
    private EditText name, extra, maxmin, notes;
    private CheckBox wipe;
    private String kind;
    private int speed;
    private Button kFn, kXc;
    private final Button[] sb = new Button[3];

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        String id = getIntent().getStringExtra("id");
        all = Slots.load(this);
        for (JSONObject x : all) if (x.optString("id").equals(id)) o = x;
        if (o == null) { finish(); return; }
        kind = o.optString("kind", "fn");
        speed = o.optInt("speed", 1);

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        root.setPadding(p, Ui.dp(this, 24), p, p);
        sv.addView(root);

        root.addView(Ui.text(this, "Editar auto click", 24, Ui.TEXT, true));

        LinearLayout c1 = Ui.card(this);
        c1.addView(Ui.text(this, "Nome", 16, Ui.TEXT, true));
        name = Ui.field(this, "Nome do auto click", false);
        name.setText(o.optString("name"));
        c1.addView(name);
        c1.addView(Ui.desc(this, "Tipo"));
        LinearLayout kr = new LinearLayout(this);
        kr.setOrientation(LinearLayout.HORIZONTAL);
        kFn = Ui.button(this, "Fortnite mobile", Ui.DARK, v -> { kind = "fn"; refresh(); });
        kXc = Ui.button(this, "xCloud", Ui.DARK, v -> { kind = "xc"; refresh(); });
        half(kFn, 0);
        half(kXc, 6);
        kr.addView(kFn);
        kr.addView(kXc);
        c1.addView(kr);
        root.addView(c1);

        LinearLayout c2 = Ui.card(this);
        c2.addView(Ui.text(this, "Velocidade de leitura", 16, Ui.TEXT, true));
        c2.addView(Ui.desc(this, "Rápido reage antes, mas gasta mais bateria."));
        LinearLayout sr = new LinearLayout(this);
        sr.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Econômico", "Normal", "Rápido"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            sb[i] = Ui.button(this, names[i], Ui.DARK, v -> { speed = idx; refresh(); });
            half(sb[i], i == 0 ? 0 : 6);
            sr.addView(sb[i]);
        }
        c2.addView(sr);
        root.addView(c2);

        LinearLayout c3 = Ui.card(this);
        c3.addView(Ui.text(this, "Sair da partida", 16, Ui.TEXT, true));
        c3.addView(Ui.desc(this, "Tempo máximo por partida, em minutos (0 desliga)."));
        maxmin = Ui.field(this, "Minutos", false);
        maxmin.setInputType(InputType.TYPE_CLASS_NUMBER);
        maxmin.setText(String.valueOf(o.optInt("maxmin", 30)));
        c3.addView(maxmin);
        wipe = new CheckBox(this);
        wipe.setText("Sair quando todo o time cair");
        wipe.setTextColor(Ui.TEXT);
        wipe.setChecked(o.optBoolean("wipe", true));
        c3.addView(wipe);
        root.addView(c3);

        LinearLayout c4 = Ui.card(this);
        c4.addView(Ui.text(this, "Palavras extras para clicar", 16, Ui.TEXT, true));
        c4.addView(Ui.desc(this, "Texto exato de botões que o app não conhece (um por linha)."));
        extra = Ui.field(this, "Ex.: ENTRAR NA FILA", true);
        extra.setText(o.optString("extra"));
        c4.addView(extra);
        root.addView(c4);

        LinearLayout c5 = Ui.card(this);
        c5.addView(Ui.text(this, "Anotações para a IA", 16, Ui.TEXT, true));
        c5.addView(Ui.desc(this, "Guarde aqui dicas sobre o jogo ou app. Serão usadas quando a IA for adicionada."));
        notes = Ui.field(this, "Ex.: o botão de jogar fica no canto direito", true);
        notes.setText(o.optString("notes"));
        c5.addView(notes);
        root.addView(c5);

        root.addView(Ui.button(this, "Salvar", Ui.ACCENT, v -> { save(); finish(); }));
        root.addView(Ui.button(this, "Cancelar", Ui.DARK, v -> finish()));
        setContentView(sv);
        refresh();
    }

    private void half(Button bt, int left) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f);
        lp.setMargins(Ui.dp(this, left), Ui.dp(this, 8), 0, 0);
        bt.setLayoutParams(lp);
    }

    private void refresh() {
        kFn.setBackground(Ui.shape(this, kind.equals("fn") ? Ui.ACCENT : Ui.DARK, 12, 0, 0));
        kXc.setBackground(Ui.shape(this, kind.equals("xc") ? Ui.ACCENT : Ui.DARK, 12, 0, 0));
        for (int i = 0; i < 3; i++) sb[i].setBackground(Ui.shape(this, i == speed ? Ui.ACCENT : Ui.DARK, 12, 0, 0));
    }

    private void save() {
        int mm = 30;
        try { mm = Math.max(0, Math.min(240, Integer.parseInt(maxmin.getText().toString().trim()))); }
        catch (Exception ignored) {}
        try {
            String n = name.getText().toString().trim();
            o.put("name", n.isEmpty() ? "Auto click" : n);
            o.put("kind", kind);
            o.put("extra", extra.getText().toString());
            o.put("maxmin", mm);
            o.put("wipe", wipe.isChecked());
            o.put("speed", speed);
            o.put("notes", notes.getText().toString());
        } catch (Exception ignored) {}
        Slots.save(this, all);
        if (o.optString("id").equals(Slots.equippedId(this))) Slots.equip(this, o);
    }
}
