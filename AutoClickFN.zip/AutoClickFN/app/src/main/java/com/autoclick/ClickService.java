package com.autoclick;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.LinearLayout;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.regex.Pattern;

public class ClickService extends AccessibilityService {

    static ClickService instance;

    // ================= FORTNITE: textos (MAIUSCULAS) =================
    static final String[] FN_REWARD = {"RESGATAR", "COLETAR", "RECEBER", "REIVINDICAR", "CLAIM", "COLLECT",
            "TOQUE PARA CONTINUAR", "TAP TO CONTINUE", "PRÓXIMO", "PROXIMO", "NEXT", "FECHAR", "CLOSE"};
    static final String[] FN_EXIT = {"SAIR DA PARTIDA", "LEAVE MATCH", "CONFIRMAR", "CONTINUAR", "CONTINUE",
            "SAIR", "SIM", "YES", "OK"};
    static final String[] FN_BACK = {"VOLTAR AO LOBBY", "VOLTAR AO SAGUÃO", "VOLTAR AO SAGUAO", "RETURN TO LOBBY"};
    static final String[] FN_PLAY = {"JOGAR", "INICIAR", "PLAY"};
    static final String[] FN_LOBBY = {"BATE-PAPO", "EQUIPAR UM"};          // so existem no lobby
    static final String[] FN_PANEL = {"COLEGAS", "SOCIAL", "REGISTRO DE VOZ", "APENAS POR CONVITE"};
    static final String[] FN_DEAD = {"VOCÊ FOI ELIMINADO", "VOCE FOI ELIMINADO", "YOU WERE ELIMINATED", "VICTORY ROYALE", "VITÓRIA"};
    static final String[] FN_STATUS = {"DESCONECTADO", "CONECTADO", "ONLINE", "OFFLINE", "AUSENTE"};

    // ================= XCLOUD: textos =================
    static final String[] XC_SKIP = {"AGORA NÃO", "AGORA NAO", "NÃO, OBRIGADO", "NAO, OBRIGADO", "NÃO OBRIGADO",
            "PULAR", "SKIP", "NOT NOW", "NO THANKS", "DISPENSAR", "DISMISS", "MAIS TARDE", "MAYBE LATER", "FECHAR", "CLOSE"};
    static final String[] XC_PLAYNOW = {"REPRODUZIR AGORA", "PLAY NOW", "JOGAR AGORA"};
    static final String[] XC_HOME = {"STREAMING GRATUITO", "JOGAR COM AMIGOS", "FREE STREAMING"};
    static final String[] XC_WAIT = {"INICIANDO O CLOUD", "ANÚNCIO 1 DE", "ANÚNCIO 2 DE", "ANÚNCIO 3 DE",
            "ANUNCIO 1 DE", "ANUNCIO 2 DE", "ANUNCIO 3 DE", "POSIÇÃO NA FILA", "NA FILA"};
    static final String[] XC_FEEDBACK = {"COMO FOI", "SUA EXPERIÊNCIA", "SUA EXPERIENCIA", "AVALIE", "PESQUISA",
            "FEEDBACK", "QUESTIONÁRIO", "QUESTIONARIO", "SURVEY", "SESSÃO ENCERRADA", "SESSÃO TERMINOU", "SESSION ENDED"};
    static final String[] XC_SUBMIT = {"ENVIAR", "SUBMIT", "CONCLUIR", "FEITO", "DONE", "SEGUINTE", "PRÓXIMO", "PROXIMO", "NEXT"};
    static final String[] XC_QUEUE = {"ENTRAR NA FILA", "JOIN QUEUE", "JOGAR NOVAMENTE", "PLAY AGAIN",
            "TENTAR NOVAMENTE", "TRY AGAIN", "RECONECTAR", "RECONNECT"};
    // "Leitor de botoes" (regras offline): botoes seguros, em ordem de prioridade
    static final String[] SMART_OK = {"PULAR", "SKIP", "AGORA NÃO", "AGORA NAO", "NÃO, OBRIGADO", "NAO, OBRIGADO",
            "MAIS TARDE", "DEPOIS", "FECHAR", "CLOSE", "ENTENDI", "OK", "CONTINUAR", "CONTINUE", "PRÓXIMO", "NEXT",
            "ACEITAR", "ACEITO", "CONCORDO", "CONFIRMAR", "TENTAR NOVAMENTE", "RECONECTAR", "INICIAR", "REPRODUZIR"};
    // se qualquer um destes aparecer na tela, o leitor NAO clica em nada (compras, assinaturas, conta)
    static final String[] SMART_BLOCK = {"COMPRAR", "COMPRA", "ASSINAR", "ASSINATURA", "ADQUIRIR", "PAGAR", "PREÇO",
            "PRECO", "R$", "V-BUCKS", "COMPARE OS PLANOS", "UPGRADE", "EXCLUIR", "DENUNCIAR", "DESCONECTAR", "SAIR DA CONTA"};

    // ================= AJUSTES (fracoes da tela) =================
    static final float JOY_X = 0.15f, JOY_Y = 0.70f;     // joystick
    static final float CAM_X = 0.70f, CAM_Y = 0.45f;     // camera
    static final float JUMP_X = 0.88f, JUMP_Y = 0.62f;   // pulo
    static final float MENU1_X = 0.975f, MENU1_Y = 0.06f; // 1o "3 tracos" (canto superior direito)
    static final float MENU2_X = 0.88f, MENU2_Y = 0.08f;  // 2o "3 tracos" (dentro da janela)
    static final int MAX_MATCH_MIN = 30;                  // seguranca: sai se a partida passar disso
    static final long CYCLE_MS = 3000;
    static final String[] SPEC_WORDS = {"ESPECTADOR", "SPECTATOR"};
    static final String[] REBOOT_WORDS = {"PROCESSANDO REINICIALIZA", "PROCESSING REBOOT"}; // so a tela de revivendo
    static final String[] STOP_WORDS = {"COLETE", "FRAGMENTO", "MAPA", "FPS", "JOGAR", "EXP", "ESPECTADOR", "COLEGA",
            "ANTERIOR", "SEGUINTE", "CARTÃO", "CARTAO", "REINICIALIZA", "ELIMINOU", "PICARETA"};
    static final Pattern NAME = Pattern.compile("[A-Z0-9_.\\-]{3,16}");
    static final int ALIVE = 3, DOWN = 2, REBOOT = 1, UNKNOWN = 0;
    // =============================================================

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random r = new Random();
    private TextRecognizer recognizer;
    private boolean running = false;
    private int W = 1920, H = 1080;
    private WindowManager wm;
    private WindowManager.LayoutParams lp;
    private boolean overlayShown = false;

    // estado da partida (Fortnite)
    private boolean inMatch = false, leaving = false, leaveClicked = false;
    private long matchStart = 0;
    private int seenReads = 0, deadReads = 0, leaveTries = 0, waitLeave = 0;
    private final Set<String> teamNames = new HashSet<>();
    private boolean fnActive = false;
    private String lastSig = "", lastLog = "";
    private int sameSig = 0;
    static final ArrayList<String> LOG = new ArrayList<>();

    static synchronized void addLog(String m) {
        LOG.add(new java.text.SimpleDateFormat("HH:mm:ss", Locale.US).format(new java.util.Date()) + " " + m);
        while (LOG.size() > 80) LOG.remove(0);
    }
    static synchronized String dumpLog() { return android.text.TextUtils.join("\n", LOG); }
    static synchronized void clearLog() { LOG.clear(); }
    private int modeFixTries = 0, smartCount = 0;
    private String lastSmart = "";

    private final Runnable loop = this::step;

    private SharedPreferences sp() { return getSharedPreferences("cfg", MODE_PRIVATE); }

    // ---------------- ciclo de vida / bolinha flutuante com menu em roda ----------------
    private static final int BUBBLE = 56, ITEM = 52, WHEEL = 260, RADIUS = 92;   // dp
    private FrameLayout box;
    private TextView bubble, statusLabel, trash;
    private final List<TextView> items = new ArrayList<>();
    private boolean expanded = false;

    @Override
    protected void onServiceConnected() {
        instance = this;
        Slots.ensure(this);
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);

        box = new FrameLayout(this);
        bubble = circle("N", BUBBLE, 18);
        box.addView(bubble);

        statusLabel = new TextView(this);
        statusLabel.setTextSize(10);
        statusLabel.setTextColor(0xFFFFFFFF);
        statusLabel.setPadding(Ui.dp(this, 8), Ui.dp(this, 4), Ui.dp(this, 8), Ui.dp(this, 4));
        statusLabel.setBackground(Ui.shape(this, 0xCC101428, 10, 0, 0));
        FrameLayout.LayoutParams sl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.START);
        sl.leftMargin = Ui.dp(this, BUBBLE + 6);
        sl.topMargin = Ui.dp(this, BUBBLE / 2 - 12);
        statusLabel.setLayoutParams(sl);
        statusLabel.setVisibility(View.GONE);
        box.addView(statusLabel);

        String[] labels = {"Play", "Próx.", "App", "Ocultar", "Desligar"};
        for (int i = 0; i < labels.length; i++) {
            final int idx = i;
            TextView it = circle(labels[i], ITEM, 9);
            it.setVisibility(View.GONE);
            it.setOnClickListener(v -> onItem(idx));
            Ui.pressable(it);
            items.add(it);
            box.addView(it);
        }

        lp = new WindowManager.LayoutParams(-2, -2,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.START;
        lp.x = 0;
        lp.y = Ui.dp(this, 120);

        // arrastar = move (solte na lixeira para ocultar); toque (ou segurar) = abre a roda
        final float[] st = new float[4];
        final boolean[] dragged = {false};
        final long[] downAt = {0};
        bubble.setOnTouchListener((v, e) -> {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    st[0] = lp.x; st[1] = lp.y; st[2] = e.getRawX(); st[3] = e.getRawY();
                    dragged[0] = false;
                    downAt[0] = System.currentTimeMillis();
                    return true;
                case MotionEvent.ACTION_MOVE: {
                    if (expanded) return true;
                    float dx = e.getRawX() - st[2], dy = e.getRawY() - st[3];
                    if (!dragged[0] && (Math.abs(dx) > 14 || Math.abs(dy) > 14)) { dragged[0] = true; showTrash(true); }
                    if (dragged[0]) {
                        lp.x = (int) (st[0] + dx);
                        lp.y = (int) (st[1] + dy);
                        try { wm.updateViewLayout(box, lp); } catch (Exception ignored) {}
                        trashHot(overTrash(e.getRawX(), e.getRawY()));
                    }
                    return true;
                }
                case MotionEvent.ACTION_UP:
                    if (dragged[0]) {
                        boolean drop = overTrash(e.getRawX(), e.getRawY());
                        showTrash(false);
                        if (drop) hideBubble(true);
                    } else {
                        long held = System.currentTimeMillis() - downAt[0];
                        long need = (long) (sp().getFloat("holdsec", 0f) * 1000);   // 0 = toque simples
                        if (held >= need) { if (expanded) collapse(); else expand(); }
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    showTrash(false);
                    return true;
            }
            return false;
        });
        refreshBubble();
        setOverlayVisible(true);
    }

    private GradientDrawable oval(int fill, int stroke) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(fill);
        g.setStroke(Ui.dp(this, 2), stroke);
        return g;
    }

    private TextView circle(String t, int sizeDp, float sp) {
        TextView v = new TextView(this);
        v.setText(t);
        v.setTextSize(sp);
        v.setTextColor(0xFFFFFFFF);
        v.setGravity(Gravity.CENTER);
        v.setTypeface(Typeface.DEFAULT_BOLD);
        v.setBackground(oval(0xE6101428, Ui.ACCENT));
        v.setLayoutParams(new FrameLayout.LayoutParams(Ui.dp(this, sizeDp), Ui.dp(this, sizeDp), Gravity.TOP | Gravity.START));
        return v;
    }

    private void setMargins(View v, int l, int t) {
        FrameLayout.LayoutParams p = (FrameLayout.LayoutParams) v.getLayoutParams();
        p.leftMargin = l;
        p.topMargin = t;
        v.setLayoutParams(p);
    }

    private void expand() {
        if (expanded || !overlayShown) return;
        expanded = true;
        int b = Ui.dp(this, BUBBLE), w = Ui.dp(this, WHEEL);
        int cx = lp.x + b / 2, cy = lp.y + b / 2;
        lp.width = w;
        lp.height = w;
        lp.x = cx - w / 2;
        lp.y = cy - w / 2;
        statusLabel.setVisibility(View.GONE);
        setMargins(bubble, (w - b) / 2, (w - b) / 2);
        int it = Ui.dp(this, ITEM), r = Ui.dp(this, RADIUS);
        for (int i = 0; i < items.size(); i++) {
            TextView v = items.get(i);
            setMargins(v, (w - it) / 2, (w - it) / 2);
            v.setVisibility(View.VISIBLE);
            v.setAlpha(0f);
            v.setScaleX(0.3f);
            v.setScaleY(0.3f);
            v.setTranslationX(0f);
            v.setTranslationY(0f);
            double ang = -Math.PI / 2 + i * 2 * Math.PI / items.size();
            v.animate().alpha(1f).scaleX(1f).scaleY(1f)
                    .translationX((float) (r * Math.cos(ang))).translationY((float) (r * Math.sin(ang)))
                    .setStartDelay(i * 30L).setDuration(220).start();
        }
        refreshBubble();
        try { wm.updateViewLayout(box, lp); } catch (Exception ignored) {}
    }

    private void collapse() {
        if (!expanded) return;
        expanded = false;
        int b = Ui.dp(this, BUBBLE), w = Ui.dp(this, WHEEL);
        int cx = lp.x + w / 2, cy = lp.y + w / 2;
        for (TextView v : items) { v.animate().cancel(); v.setVisibility(View.GONE); }
        setMargins(bubble, 0, 0);
        lp.width = -2;
        lp.height = -2;
        lp.x = cx - b / 2;
        lp.y = cy - b / 2;
        refreshBubble();
        try { wm.updateViewLayout(box, lp); } catch (Exception ignored) {}
    }

    private void onItem(int i) {
        switch (i) {
            case 0: toggle(); collapse(); break;
            case 1: {
                String n = Slots.next(this);
                if (n != null) {
                    addLog("auto click: " + n);
                    android.widget.Toast.makeText(this, n, android.widget.Toast.LENGTH_SHORT).show();
                }
                break;
            }
            case 2: {
                collapse();
                Intent in = new Intent(this, MainActivity.class);
                in.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                try { startActivity(in); } catch (Exception ignored) {}
                break;
            }
            case 3: hideBubble(true); break;
            case 4: shutdown(); break;
        }
    }

    private void refreshBubble() {
        if (bubble == null) return;
        bubble.setBackground(oval(0xE6101428, running ? Ui.OK : Ui.ACCENT));
        bubble.setText(running ? "■" : "N");
        if (!items.isEmpty()) items.get(0).setText(running ? "Stop" : "Play");
        statusLabel.setVisibility(running && !expanded ? View.VISIBLE : View.GONE);
    }

    // ---- lixeira ----
    private void showTrash(boolean show) {
        if (wm == null) return;
        try {
            if (show && trash == null) {
                trash = circle("Lixo", 64, 11);
                trash.setBackground(oval(0xE6301020, Ui.DANGER));
                WindowManager.LayoutParams p = new WindowManager.LayoutParams(Ui.dp(this, 64), Ui.dp(this, 64),
                        WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                        WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                        PixelFormat.TRANSLUCENT);
                p.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
                p.y = Ui.dp(this, 48);
                wm.addView(trash, p);
            } else if (!show && trash != null) {
                wm.removeView(trash);
                trash = null;
            }
        } catch (Exception ignored) {}
    }

    private boolean overTrash(float rx, float ry) {
        DisplayMetrics m = getResources().getDisplayMetrics();
        return ry > m.heightPixels - Ui.dp(this, 48 + 64 + 24) && Math.abs(rx - m.widthPixels / 2f) < Ui.dp(this, 70);
    }

    private void trashHot(boolean hot) {
        if (trash == null) return;
        trash.setScaleX(hot ? 1.25f : 1f);
        trash.setScaleY(hot ? 1.25f : 1f);
    }

    // ---- mostrar / ocultar ----
    void setOverlayVisible(boolean show) {
        if (wm == null || box == null) return;
        try {
            if (show && !overlayShown) {
                wm.addView(box, lp);
                overlayShown = true;
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (nm != null) nm.cancel(7);
            } else if (!show && overlayShown) {
                if (expanded) collapse();
                wm.removeView(box);
                overlayShown = false;
            }
        } catch (Exception ignored) {}
        refreshBubble();
    }

    void hideBubble(boolean notify) {
        setOverlayVisible(false);
        if (notify) notifyRestore();
    }

    private void notifyRestore() {
        try {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel("restore", "Bolinha flutuante", NotificationManager.IMPORTANCE_LOW));
            PendingIntent pi = PendingIntent.getBroadcast(this, 1, new Intent(this, RestoreReceiver.class),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            Notification n = new Notification.Builder(this, "restore")
                    .setSmallIcon(android.R.drawable.ic_menu_view)
                    .setContentTitle("Bolinha oculta")
                    .setContentText("Toque para mostrar de novo")
                    .setContentIntent(pi)
                    .setAutoCancel(true)
                    .build();
            nm.notify(7, n);
        } catch (Exception ignored) {}
    }

    /** Desliga tudo: para o loop, remove a bolinha e desativa o servico de acessibilidade. */
    void shutdown() {
        stopRun();
        setOverlayVisible(false);
        try { disableSelf(); } catch (Exception ignored) {}
    }

    private void stopRun() {
        running = false;
        h.removeCallbacksAndMessages(null);
        refreshBubble();
    }

    private void toggle() {
        if (running) { stopRun(); return; }
        running = true;
        inMatch = false; leaving = false; leaveClicked = false;
        fnActive = false; modeFixTries = 0; smartCount = 0; lastSmart = ""; sameSig = 0; lastSig = "";
        refreshBubble();
        h.postDelayed(loop, 800);
    }

    private void status(String s) {
        if (!s.equals(lastLog)) { lastLog = s; addLog(s); }
        if (running && statusLabel != null) statusLabel.setText(s.length() > 28 ? s.substring(0, 28) : s);
    }

    private void next() {
        if (!running) return;
        int spd = sp().getInt("speed", 1);                      // 0 economico, 1 normal, 2 rapido
        long menu = spd == 2 ? 900 : spd == 0 ? 2500 : 1500;
        long match = spd == 2 ? 2500 : spd == 0 ? 5000 : 3500;
        h.postDelayed(loop, (inMatch && !leaving ? match : menu) + r.nextInt(400));
    }

    // ---------------- print -> OCR -> decisao ----------------
    private void step() {
        if (!running) return;
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult res) {
                HardwareBuffer hb = res.getHardwareBuffer();
                Bitmap hw = Bitmap.wrapHardwareBuffer(hb, res.getColorSpace());
                if (hw == null) { hb.close(); status("print falhou"); next(); return; }
                final Bitmap bmp = hw.copy(Bitmap.Config.ARGB_8888, false);
                hw.recycle();
                hb.close();
                if (bmp == null) { next(); return; }
                W = bmp.getWidth();
                H = bmp.getHeight();
                recognizer.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener(t -> { try { analyze(t, bmp); } finally { bmp.recycle(); } next(); })
                        .addOnFailureListener(e -> { bmp.recycle(); next(); });
            }
            @Override public void onFailure(int code) { status("print erro " + code); next(); }
        });
    }

    private void analyze(Text t, Bitmap bmp) {
        List<String> tx = new ArrayList<>();
        List<Rect> bx = new ArrayList<>();
        Rect mine = null;
        if (overlayShown && box.getWidth() > 0)
            mine = new Rect(lp.x, lp.y, lp.x + box.getWidth(), lp.y + box.getHeight());
        for (Text.TextBlock b : t.getTextBlocks()) {
            for (Text.Line l : b.getLines()) {
                Rect bb = l.getBoundingBox();
                if (bb == null) continue;
                if (mine != null && Rect.intersects(mine, bb)) continue; // ignora o proprio botao
                String up = l.getText().toUpperCase(Locale.ROOT).trim();
                if (up.contains("CONTINUAR JOGANDO") || up.contains("CONTINUE PLAYING")) continue; // titulo de secao, nao botao
                tx.add(up);
                bx.add(bb);
            }
        }
        String mode = sp().getString("mode", "fn");

        // detector de travamento: mesma tela por muito tempo
        String sig = signature(tx);
        if (!inMatch && !sig.equals(lastSig)) addLog("tela: " + sig);
        if (sig.equals(lastSig)) sameSig++; else { sameSig = 0; lastSig = sig; }
        if (sameSig >= 10 && !leaving && !inMatch) {
            sameSig = 0;
            addLog("travado: reiniciando estado");
            fnActive = false; modeFixTries = 0; teamNames.clear();
            int sk = smartPick(tx, bx);
            if (sk >= 0) { clickBox(bx.get(sk), tx.get(sk)); return; }
        }

        // palavras extras que o usuario digitou no app
        String extra = sp().getString("extra_" + mode, "");
        List<String> ex = new ArrayList<>();
        for (String s : extra.split("\n")) { s = s.trim().toUpperCase(Locale.ROOT); if (!s.isEmpty()) ex.add(s); }
        if (!ex.isEmpty()) {
            int e = find(tx, bx, ex.toArray(new String[0]));
            if (e >= 0) { clickBox(bx.get(e), tx.get(e)); return; }
        }

        if ("xc".equals(mode)) analyzeXcloud(tx, bx, bmp);
        else analyzeFortnite(tx, bx, bmp);
    }

    // ---------------- XCLOUD ----------------
    private boolean xc() { return "xc".equals(sp().getString("mode", "fn")); }

    private void analyzeXcloud(List<String> tx, List<Rect> bx, Bitmap bmp) {
        boolean lobby = find(tx, bx, FN_LOBBY) >= 0;
        boolean xbox = find(tx, bx, XC_PLAYNOW) >= 0 || find(tx, bx, XC_HOME) >= 0
                || find(tx, bx, XC_WAIT) >= 0 || find(tx, bx, XC_FEEDBACK) >= 0;
        if (lobby) fnActive = true;
        else if (xbox) { fnActive = false; modeFixTries = 0; }
        if (fnActive) { analyzeFortnite(tx, bx, bmp); return; }   // dentro do jogo: mesma logica do Fortnite

        int i = find(tx, bx, XC_PLAYNOW);                          // pagina do jogo
        if (i >= 0) { clickBox(bx.get(i), tx.get(i)); return; }

        i = find(tx, bx, XC_HOME);                                 // tela inicial do xCloud: abre o Fortnite
        if (i >= 0) {
            int f = find(tx, bx, new String[]{"FORTNITE"});
            if (f >= 0) clickBox(bx.get(f), "FORTNITE");
            else { tap(W * 0.33f, bx.get(i).bottom + H * 0.09f); status("abrindo Fortnite"); }
            return;
        }
        i = find(tx, bx, XC_SKIP);                                 // anuncio do jogo / aviso: pula
        if (i >= 0) { clickBox(bx.get(i), tx.get(i)); return; }
        i = find(tx, bx, XC_QUEUE);                                // sessao acabou: entra na fila de novo
        if (i >= 0) { clickBox(bx.get(i), tx.get(i)); return; }

        if (find(tx, bx, XC_FEEDBACK) >= 0) {                      // questionario: qualquer resposta volta ao inicio
            i = find(tx, bx, XC_SUBMIT);
            if (i >= 0) clickBox(bx.get(i), tx.get(i));
            else { performGlobalAction(GLOBAL_ACTION_BACK); status("pulando questionario"); }
            return;
        }
        if (find(tx, bx, XC_WAIT) >= 0) { status("xCloud: fila / anuncios"); return; }

        i = smartPick(tx, bx);                                     // leitor de botoes (regras offline)
        if (i >= 0) { clickBox(bx.get(i), tx.get(i)); return; }
        status("xCloud: aguardando");
    }

    /** Leitor de botoes: escolhe o botao "seguro" mais provavel; nunca age em telas de compra. */
    private String signature(List<String> tx) {
        List<String> c = new ArrayList<>(tx);
        java.util.Collections.sort(c);
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < c.size() && i < 8; i++) { if (i > 0) sb.append('|'); sb.append(c.get(i)); }
        return sb.toString();
    }

    private int smartPick(List<String> tx, List<Rect> bx) {
        for (String s : tx) for (String b : SMART_BLOCK) if (s.contains(b)) return -1;
        int best = -1, bestPri = Integer.MAX_VALUE;
        for (int i = 0; i < tx.size(); i++) {
            String s = tx.get(i);
            if (s.length() > 30) continue;
            for (int p = 0; p < SMART_OK.length; p++) {
                String w = SMART_OK[p];
                boolean ok = w.length() <= 4 ? s.equals(w) : s.contains(w);
                if (ok && p < bestPri) { bestPri = p; best = i; break; }
            }
        }
        if (best < 0) { smartCount = 0; lastSmart = ""; return -1; }
        String label = tx.get(best);
        if (label.equals(lastSmart)) { if (++smartCount > 3) return -1; }
        else { lastSmart = label; smartCount = 1; }
        return best;
    }

    /** Navega pelo lobby: nunca clica Jogar na vitrine de modos; usa coracao -> Battle Royale. */
    private boolean lobbyNavigate(List<String> tx, List<Rect> bx) {
        boolean discover = find(tx, bx, new String[]{"IR PARA O LOBBY", "CHAVE PERSONALIZADA"}) >= 0;
        boolean biblio = !discover && find(tx, bx, new String[]{"BIBLIOTECA"}) >= 0;

        if (biblio) {                                              // aba Biblioteca: clica no card Battle Royale
            int c = find(tx, bx, new String[]{"BATTLE ROYALE"});
            if (c >= 0) { clickBox(bx.get(c), "BATTLE ROYALE"); return true; }
            float[] p = navIcon(tx, bx, false);
            tap(p[0], p[1]);
            status("biblioteca: sem card, voltando");
            return true;
        }
        if (discover) {                                            // vitrine de modos (troca sozinha): nao clicar Jogar aqui
            if (modeFixTries < 3) {
                modeFixTries++;
                float[] p = navIcon(tx, bx, true);                 // coracao
                tap(p[0], p[1]);
                status("vitrine de modos: abrindo biblioteca");
            } else {
                int g = find(tx, bx, new String[]{"IR PARA O LOBBY"});
                if (g >= 0) clickBox(bx.get(g), "IR PARA O LOBBY"); else status("vitrine: aguardando");
            }
            return true;
        }
        if (tabLabel(tx, bx, "JOGAR") < 0) {                       // outra aba (Tesouro, Loja...)
            float[] p = navIcon(tx, bx, false);
            tap(p[0], p[1]);
            status("indo para a aba Jogar");
            return true;
        }
        if (modeFixTries < 3 && !hasBattleTitle(tx, bx)) {         // lobby com outro modo selecionado
            modeFixTries++;
            float[] p = navIcon(tx, bx, true);
            tap(p[0], p[1]);
            status("modo diferente: abrindo biblioteca");
            return true;
        }
        return false;
    }

    /** Rotulo da aba selecionada no topo (JOGAR, BIBLIOTECA, TESOURO). */
    private int tabLabel(List<String> tx, List<Rect> bx, String name) {
        for (int i = 0; i < tx.size(); i++) {
            Rect b = bx.get(i);
            if (b.centerY() < H * 0.22f && b.centerX() < W * 0.6f && tx.get(i).equals(name)) return i;
        }
        return -1;
    }

    /** Posicao do icone coracao (heart) ou play, calculada a partir do rotulo da aba atual. */
    private float[] navIcon(List<String> tx, List<Rect> bx, boolean heart) {
        float step = 0.05f * W, dy = 0.061f * H;
        int i = tabLabel(tx, bx, "JOGAR");
        if (i >= 0) { Rect b = bx.get(i); return new float[]{b.centerX() - (heart ? step : 0), b.centerY() - dy}; }
        i = tabLabel(tx, bx, "BIBLIOTECA");
        if (i >= 0) { Rect b = bx.get(i); return new float[]{b.centerX() + (heart ? 0 : step), b.centerY() - dy}; }
        i = tabLabel(tx, bx, "TESOURO");
        if (i >= 0) { Rect b = bx.get(i); return new float[]{b.centerX() - (heart ? 2 * step : step), b.centerY() - dy}; }
        return heart ? new float[]{W * 0.152f, H * 0.093f} : new float[]{W * 0.202f, H * 0.093f};
    }

    /** Botao JOGAR grande (ignora o rotulo da aba no topo). */
    private int playButton(List<String> tx, List<Rect> bx) {
        int best = -1;
        long bestA = -1;
        for (int i = 0; i < tx.size(); i++) {
            String s = tx.get(i);
            if (!(s.contains("JOGAR") || s.equals("INICIAR") || s.equals("PLAY"))) continue;
            if (s.contains("AMIGOS")) continue;
            Rect b = bx.get(i);
            if (b.centerY() < H * 0.22f) continue;
            long a = (long) b.width() * b.height();
            if (a > bestA) { bestA = a; best = i; }
        }
        return best;
    }

    private boolean hasBattleTitle(List<String> tx, List<Rect> bx) {
        for (int i = 0; i < tx.size(); i++) {
            String s = tx.get(i);
            if (!s.contains("BATTLE") && !s.contains("ROYALE")) continue;
            Rect b = bx.get(i);
            float cx = b.centerX() / (float) W, cy = b.centerY() / (float) H;
            if (cx < 0.30f && cy > 0.38f && cy < 0.70f) return true;
        }
        return false;
    }

    // ---------------- FORTNITE ----------------
    private void analyzeFortnite(List<String> tx, List<Rect> bx, Bitmap bmp) {
        int i = find(tx, bx, FN_REWARD);
        if (i >= 0) { clickBox(bx.get(i), tx.get(i)); return; }
        i = find(tx, bx, FN_EXIT);
        if (i >= 0) { clickBox(bx.get(i), tx.get(i)); return; }

        // lobby
        if (find(tx, bx, FN_LOBBY) >= 0) {
            inMatch = false; leaving = false; leaveClicked = false;
            teamNames.clear();
            learnNick(tx, bx);
            if (lobbyNavigate(tx, bx)) return;
            i = playButton(tx, bx);
            if (i >= 0) { modeFixTries = 0; clickBox(bx.get(i), tx.get(i)); } else status("lobby: aguardando");
            return;
        }

        if (leaving) { leaveStep(tx, bx); return; }

        long now = System.currentTimeMillis();
        if (!inMatch) { inMatch = true; matchStart = now; seenReads = 0; deadReads = 0; teamNames.clear(); modeFixTries = 0; }

        // tela preta "Processando reinicializacao / Realocando": estao te revivendo
        if (find(tx, bx, REBOOT_WORDS) >= 0) { deadReads = 0; status("reiniciando..."); return; }

        // 1) le a barra de cada companheiro (verde = vivo, vermelho = caido, so azul = cartao de reinicializacao)
        Map<String, Integer> st = new LinkedHashMap<>();
        String own = ownNick();
        for (int k = 0; k < tx.size(); k++) {
            Rect b = bx.get(k);
            if (!inTeamZone(b.centerX() / (float) W, b.centerY() / (float) H)) continue;
            String tk = nameToken(tx.get(k));
            if (tk == null || isOwn(tk, own)) continue;
            int s = barStatus(bmp, b);
            if (s == UNKNOWN) continue;
            Integer o = st.get(tk);
            if (o == null || s > o) st.put(tk, s);
        }
        int alive = 0, dead = 0;
        for (Map.Entry<String, Integer> e : st.entrySet()) {
            teamNames.add(e.getKey());
            if (e.getValue() == ALIVE) alive++; else dead++;
        }
        if (!st.isEmpty()) seenReads++;

        // 2) voce esta morto? (modo espectador). Quem voce esta assistindo e do time?
        int sp = find(tx, bx, SPEC_WORDS);
        boolean userDead = sp >= 0;
        boolean specBlocked = false;
        if (userDead) {
            Rect sr = bx.get(sp);
            String tgt = null;
            for (int k = 0; k < tx.size() && tgt == null; k++) {
                if (k == sp) continue;
                Rect b = bx.get(k);
                if (b.top < sr.top - 5 || b.top - sr.bottom > H * 0.12) continue;
                if (Math.abs(b.centerX() - sr.centerX()) > W * 0.15) continue;
                tgt = nameToken(tx.get(k));
            }
            // assistindo um companheiro que nao aparece na lista = ele esta vivo
            if (tgt != null && inSet(teamNames, tgt) && !inSet(st.keySet(), tgt)) specBlocked = true;
        }

        boolean cond = userDead && alive == 0 && dead >= 1 && !specBlocked;
        deadReads = cond ? deadReads + 1 : 0;

        boolean old = now - matchStart > 45000;
        boolean wiped = cond && deadReads >= 3 && old && seenReads >= 2 && sp().getBoolean("wipe", true);
        boolean soloDead = seenReads < 2 && old && find(tx, bx, FN_DEAD) >= 0;
        int maxMin = sp().getInt("maxmin", MAX_MATCH_MIN);
        boolean timeout = maxMin > 0 && now - matchStart > maxMin * 60000L;

        if (wiped || soloDead || timeout) {
            leaving = true; leaveClicked = false; leaveTries = 0; waitLeave = 0;
            leaveStep(tx, bx);
            return;
        }
        status("vivos " + alive + " | caidos " + dead + (userDead ? " | espectador" : "")
                + (own.isEmpty() ? " | sem nick" : ""));
        if (!userDead) antiAfk();
    }

    /** Sair: 3 tracos -> 3 tracos -> Voltar ao Lobby. */
    private void leaveStep(List<String> tx, List<Rect> bx) {
        if (leaveClicked) {
            if (++waitLeave > 10) { leaving = false; leaveClicked = false; inMatch = false; }
            else status("saindo...");
            return;
        }
        int i = find(tx, bx, FN_BACK);
        if (i >= 0) { clickBox(bx.get(i), tx.get(i)); leaveClicked = true; waitLeave = 0; return; }
        if (++leaveTries > 15) { leaving = false; inMatch = false; return; }
        if (find(tx, bx, FN_PANEL) >= 0) tap(W * MENU2_X, H * MENU2_Y);
        else tap(W * MENU1_X, H * MENU1_Y);
        status("abrindo menu");
    }

    /** Areas onde a lista do time aparece: esquerda (quando morto) e canto inferior direito (vivo). */
    private boolean inTeamZone(float cx, float cy) {
        return (cx <= 0.26f && cy >= 0.30f && cy <= 0.82f) || (cx >= 0.70f && cx <= 0.97f && cy >= 0.62f && cy <= 0.98f);
    }

    /** Primeiro "token" da linha, se parecer um nick (ignora icones e textos de HUD). */
    private String nameToken(String s) {
        for (String p : s.split("\\s+")) {
            p = p.replaceAll("^[^A-Z0-9]+", "").replaceAll("[^A-Z0-9_.\\-]+$", "");
            if (p.isEmpty()) continue;
            if (!NAME.matcher(p).matches()) return null;
            int letters = 0;
            for (char c : p.toCharArray()) if (Character.isLetter(c)) letters++;
            if (letters < 2) return null;
            for (String w : STOP_WORDS) if (p.contains(w)) return null;
            return p;
        }
        return null;
    }

    private boolean inSet(java.util.Collection<String> set, String n) {
        for (String e : set) if (e.equals(n) || lev(e, n) <= Math.max(1, e.length() / 4)) return true;
        return false;
    }

    /** Olha as barrinhas logo abaixo do nome: verde = vivo; vermelho = caido; so azul = cartao de reinicializacao. */
    private int barStatus(Bitmap bmp, Rect name) {
        int bw = bmp.getWidth(), bh = bmp.getHeight();
        int l = Math.max(0, name.left - (int) (0.012f * bw));
        int rr = Math.min(bw, l + (int) (0.14f * bw));
        int t = Math.min(bh - 1, name.bottom + 1);
        int bt = Math.min(bh, name.bottom + (int) (0.055f * bh));
        int w = rr - l, hh = bt - t;
        if (w < 20 || hh < 4) return UNKNOWN;
        int[] px = new int[w * hh];
        bmp.getPixels(px, 0, w, l, t, w, hh);
        int minRun = Math.max(6, (int) (0.010f * bw));
        boolean g = false, rd = false, bl = false;
        for (int y = 0; y < hh; y++) {
            int cg = 0, cr = 0, cb = 0;
            for (int x = 0; x < w; x++) {
                int p = px[y * w + x];
                int R = (p >> 16) & 255, G = (p >> 8) & 255, B = p & 255;
                boolean isG = G >= 150 && G - R >= 35 && G - B >= 80;
                boolean isR = R >= 170 && R - G >= 90 && R - B >= 80;
                boolean isB = B >= 170 && B - R >= 90 && G >= 90 && G <= 235;
                cg = isG ? cg + 1 : 0;
                cr = isR ? cr + 1 : 0;
                cb = isB ? cb + 1 : 0;
                if (cg >= minRun) g = true;
                if (cr >= minRun) rd = true;
                if (cb >= minRun) bl = true;
            }
        }
        return g ? ALIVE : rd ? DOWN : bl ? REBOOT : UNKNOWN;
    }

    private String ownNick() {
        String n = sp().getString("nick", "").trim();
        if (n.isEmpty()) n = sp().getString("nick_auto", "").trim();
        return n.toUpperCase(Locale.ROOT);
    }

    private boolean isOwn(String s, String own) {
        if (own.isEmpty()) return false;
        if (s.contains(own) || (s.length() >= 3 && own.contains(s))) return true;
        return lev(s, own) <= Math.max(1, own.length() / 4);
    }

    private static int lev(String a, String b) {
        int[] p = new int[b.length() + 1];
        for (int j = 0; j <= b.length(); j++) p[j] = j;
        for (int i = 1; i <= a.length(); i++) {
            int prev = p[0];
            p[0] = i;
            for (int j = 1; j <= b.length(); j++) {
                int tmp = p[j];
                p[j] = Math.min(Math.min(p[j] + 1, p[j - 1] + 1), prev + (a.charAt(i - 1) == b.charAt(j - 1) ? 0 : 1));
                prev = tmp;
            }
        }
        return p[b.length()];
    }

    /** No lobby, le o nick do personagem (linha logo acima de "Desconectado"/"Online"). */
    private void learnNick(List<String> tx, List<Rect> bx) {
        if (!sp().getString("nick", "").trim().isEmpty()) return;
        int st = find(tx, bx, FN_STATUS);
        if (st < 0) return;
        Rect s = bx.get(st);
        float cx = s.centerX() / (float) W, cy = s.centerY() / (float) H;
        if (cx < 0.25f || cx > 0.75f || cy > 0.45f) return;
        int best = -1;
        for (int i = 0; i < tx.size(); i++) {
            if (i == st) continue;
            Rect b = bx.get(i);
            if (b.bottom > s.top + 10 || s.top - b.bottom > H * 0.12) continue;
            if (Math.abs(b.centerX() - s.centerX()) > W * 0.2) continue;
            if (best < 0 || b.bottom > bx.get(best).bottom) best = i;
        }
        if (best >= 0 && NAME.matcher(tx.get(best)).matches())
            sp().edit().putString("nick_auto", tx.get(best)).apply();
    }

    // ---------------- utilitarios ----------------
    /** Procura por prioridade; entre achados da mesma palavra, pega o MAIOR (ex.: botao grande JOGAR). */
    private int find(List<String> tx, List<Rect> bx, String[] words) {
        for (String w : words) {
            int best = -1;
            long bestA = -1;
            for (int i = 0; i < tx.size(); i++) {
                String s = tx.get(i);
                boolean ok = w.length() <= 4 ? s.equals(w) : s.contains(w);
                if (ok) {
                    Rect b = bx.get(i);
                    long a = (long) b.width() * b.height();
                    if (a > bestA) { bestA = a; best = i; }
                }
            }
            if (best >= 0) return best;
        }
        return -1;
    }

    private void clickBox(Rect b, String label) {
        status("clicou: " + label);
        tap(b.centerX(), b.centerY());
    }

    private void antiAfk() {
        float jx = W * JOY_X, jy = H * JOY_Y;
        float cx = W * CAM_X, cy = H * CAM_Y;
        GestureDescription.Builder g = new GestureDescription.Builder();
        g.addStroke(stroke(jx, jy, jx + rnd(120), jy + rnd(120), 1800));
        g.addStroke(stroke(cx, cy, cx + rnd(200), cy + rnd(60), 1800));
        dispatchGesture(g.build(), null, null);
        if (r.nextInt(100) < 40) h.postDelayed(() -> tap(W * JUMP_X, H * JUMP_Y), 2000);
    }

    private float rnd(int range) { return r.nextInt(range * 2 + 1) - range; }

    private GestureDescription.StrokeDescription stroke(float x1, float y1, float x2, float y2, long dur) {
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        return new GestureDescription.StrokeDescription(p, 0, dur);
    }

    private void tap(float x, float y) {
        if (!running) return;
        Path p = new Path();
        p.moveTo(x, y);
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}

    @Override
    public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        setOverlayVisible(false);
        if (recognizer != null) recognizer.close();
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
