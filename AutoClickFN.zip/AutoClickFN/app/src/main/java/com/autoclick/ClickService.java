package com.autoclick;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Bitmap;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Rect;
import android.hardware.HardwareBuffer;
import android.os.Handler;
import android.os.Looper;
import android.view.Display;
import android.view.Gravity;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;

import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Random;
import java.util.Set;

public class ClickService extends AccessibilityService {

    // ===== AJUSTE AQUI =====
    // Textos (em MAIUSCULAS) que o app procura na tela. Adicione os que aparecem no SEU jogo.
    // Ordem = prioridade. Cada grupo e verificado na ordem.
    static final String[] EXIT_WORDS = {
            "SAIR DA PARTIDA", "VOLTAR AO LOBBY", "VOLTAR AO SAGUÃO", "VOLTAR PARA O LOBBY",
            "LEAVE MATCH", "RETURN TO LOBBY", "CONTINUAR", "CONTINUE", "SAIR", "SIM", "YES"
    };
    // Telas de recompensa depois da partida (XP, missoes, nivel, passe de batalha)
    static final String[] REWARD_WORDS = {
            "RESGATAR", "COLETAR", "RECEBER", "REIVINDICAR", "CLAIM", "COLLECT",
            "TOQUE PARA CONTINUAR", "TAP TO CONTINUE", "PRÓXIMO", "NEXT", "FECHAR", "CLOSE"
    };
    static final String[] PLAY_WORDS = { "JOGAR", "INICIAR", "PLAY" };
    // Textos que indicam que a partida acabou / voce foi eliminado
    static final String[] OVER_WORDS = {
            "ELIMINADO", "ELIMINATED", "DERROTA", "VITÓRIA", "VICTORY", "SEU TIME FOI", "FIM DE JOGO"
    };
    // Palavras curtas: so valem se a linha for IGUAL (evita falso positivo)
    static final Set<String> EXACT = new HashSet<>(Arrays.asList("SAIR", "SIM", "YES", "PLAY", "OK", "FECHAR", "CLOSE", "NEXT"));

    // Botao de menu/pausa dentro da partida (canto superior direito) - usado quando perde
    static final float MENU_X = 0.96f, MENU_Y = 0.07f;
    // Controles (fracoes da tela)
    static final float JOY_X = 0.15f, JOY_Y = 0.70f;
    static final float CAM_X = 0.70f, CAM_Y = 0.45f;
    static final float JUMP_X = 0.88f, JUMP_Y = 0.62f;
    static final long CYCLE_MS = 3000;
    // =======================

    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random r = new Random();
    private TextRecognizer recognizer;
    private boolean running = false;
    private int W = 1080, H = 2400;
    private Button btn;
    private WindowManager wm;

    private final Runnable loop = this::step;

    @Override
    protected void onServiceConnected() {
        recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        btn = new Button(this);
        btn.setText("▶ Iniciar");
        btn.setAlpha(0.8f);
        btn.setOnClickListener(v -> toggle());
        WindowManager.LayoutParams p = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
                PixelFormat.TRANSLUCENT);
        p.gravity = Gravity.TOP | Gravity.START;
        p.x = 0;
        p.y = 200;
        wm.addView(btn, p);
    }

    private void toggle() {
        running = !running;
        btn.setText(running ? "■ Parar" : "▶ Iniciar");
        h.removeCallbacksAndMessages(null);
        if (running) h.postDelayed(loop, 800);
    }

    private void status(String s) {
        if (running) btn.setText("■ Parar\n" + s);
    }

    private void next() {
        if (running) h.postDelayed(loop, CYCLE_MS + r.nextInt(1000));
    }

    // 1) tira print -> 2) OCR -> 3) decide
    private void step() {
        if (!running) return;
        takeScreenshot(Display.DEFAULT_DISPLAY, getMainExecutor(), new TakeScreenshotCallback() {
            @Override public void onSuccess(ScreenshotResult res) {
                HardwareBuffer hb = res.getHardwareBuffer();
                Bitmap hw = Bitmap.wrapHardwareBuffer(hb, res.getColorSpace());
                if (hw == null) { hb.close(); status("print falhou"); next(); return; }
                Bitmap bmp = hw.copy(Bitmap.Config.ARGB_8888, false);
                hw.recycle();
                hb.close();
                if (bmp == null) { next(); return; }
                W = bmp.getWidth();
                H = bmp.getHeight();
                recognizer.process(InputImage.fromBitmap(bmp, 0))
                        .addOnSuccessListener(t -> { analyze(t); next(); })
                        .addOnFailureListener(e -> { antiAfk(); next(); });
            }
            @Override public void onFailure(int code) {
                status("print erro " + code);
                next();
            }
        });
    }

    private void analyze(Text t) {
        List<String> texts = new ArrayList<>();
        List<Rect> boxes = new ArrayList<>();
        for (Text.TextBlock b : t.getTextBlocks()) {
            for (Text.Line l : b.getLines()) {
                Rect bb = l.getBoundingBox();
                if (bb == null) continue;
                texts.add(l.getText().toUpperCase(Locale.ROOT).trim());
                boxes.add(bb);
            }
        }

        // recompensas: resgata antes de qualquer outra coisa
        int i = find(texts, REWARD_WORDS);
        if (i >= 0) { clickBox(boxes.get(i), texts.get(i)); return; }

        // botoes de saida / continuar
        i = find(texts, EXIT_WORDS);
        if (i >= 0) { clickBox(boxes.get(i), texts.get(i)); return; }

        // botao jogar (lobby)
        i = find(texts, PLAY_WORDS);
        if (i >= 0) { clickBox(boxes.get(i), texts.get(i)); return; }

        // partida acabou / eliminado, mas sem botao visivel: abre o menu para sair
        if (find(texts, OVER_WORDS) >= 0) {
            status("fim de jogo: menu");
            tap(W * MENU_X, H * MENU_Y);
            return;
        }

        // nenhum texto de menu: esta em partida -> anti-AFK
        status("em partida");
        antiAfk();
    }

    private int find(List<String> texts, String[] words) {
        for (String w : words) {
            for (int i = 0; i < texts.size(); i++) {
                String s = texts.get(i);
                if (EXACT.contains(w) ? s.equals(w) : s.contains(w)) return i;
            }
        }
        return -1;
    }

    private void clickBox(Rect b, String label) {
        status("clicou: " + label);
        tap(b.centerX(), b.centerY());
    }

    private void antiAfk() {
        float jx = W * JOY_X, jy = H * JOY_Y;
        float cx = W * CAM_X, cy = H * CAM_Y;
        GestureDescription.Builder g = new GestureDescription.Builder();
        g.addStroke(stroke(jx, jy, jx + rnd(120), jy + rnd(120), 1800));
        g.addStroke(stroke(cx, cy, cx + rnd(200), cy + rnd(60), 1800));
        dispatchGesture(g.build(), null, null);
        if (r.nextInt(100) < 40) h.postDelayed(() -> tap(W * JUMP_X, H * JUMP_Y), 2000);
    }

    private float rnd(int range) { return r.nextInt(range * 2 + 1) - range; }

    private GestureDescription.StrokeDescription stroke(float x1, float y1, float x2, float y2, long dur) {
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        return new GestureDescription.StrokeDescription(p, 0, dur);
    }

    private void tap(float x, float y) {
        if (!running) return;
        Path p = new Path();
        p.moveTo(x, y);
        dispatchGesture(new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(p, 0, 60)).build(), null, null);
    }

    @Override public void onAccessibilityEvent(AccessibilityEvent e) {}
    @Override public void onInterrupt() {}

    @Override
    public void onDestroy() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (wm != null && btn != null) wm.removeView(btn);
        if (recognizer != null) recognizer.close();
        super.onDestroy();
    }
}
