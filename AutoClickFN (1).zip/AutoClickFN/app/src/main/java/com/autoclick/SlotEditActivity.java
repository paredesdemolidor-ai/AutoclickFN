package com.autoclick;

import android.app.Activity;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;

import org.json.JSONObject;

import java.util.List;

public class SlotEditActivity extends Activity {
    private List<JSONObject> all;
    private JSONObject o;
    private EditText name, extra, maxmin, notes, rules;
    private CheckBox wipe, afk;
    private String kind, endact;
    private int speed;
    private final Button[] kb = new Button[3];
    private final Button[] sb = new Button[3];
    private final Button[] eb = new Button[2];
    private LinearLayout gameBox, customBox;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        String id = getIntent().getStringExtra("id");
        all = Slots.load(this);
        for (JSONObject x : all) if (x.optString("id").equals(id)) o = x;
        if (o == null) { finish(); return; }
        kind = o.optString("kind", "fn");
        speed = o.optInt("speed", 1);
        endact = o.optString("endact", "lobby");

        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        root.setPadding(p, Ui.dp(this, 24), p, p);
        sv.addView(root);
        root.addView(Ui.header(this, "Editar auto click"));

        LinearLayout c1 = Ui.card(this);
        c1.addView(Ui.text(this, "Nome", 16, Ui.TEXT, true));
        name = Ui.field(this, "Nome do auto click", false);
        name.setText(o.optString("name"));
        c1.addView(name);
        c1.addView(Ui.desc(this, "Tipo"));
        String[] kn = {"Fortnite", "xCloud", "Livre"};
        final String[] kk = {"fn", "xc", "custom"};
        LinearLayout kr = new LinearLayout(this);
        kr.setOrientation(LinearLayout.HORIZONTAL);
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            kb[i] = Ui.button(this, kn[i], Ui.DARK, v -> { kind = kk[idx]; refresh(); });
            half(kb[i], i == 0 ? 0 : 6);
            kr.addView(kb[i]);
        }
        c1.addView(kr);
        if (!BuildConfig.STUDIO && !"custom".equals(kind)) kb[2].setVisibility(View.GONE);
        root.addView(c1);

        LinearLayout c2 = Ui.card(this);
        c2.addView(Ui.text(this, "Velocidade de leitura", 16, Ui.TEXT, true));
        c2.addView(Ui.desc(this, "Rápido reage antes, mas gasta mais bateria."));
        LinearLayout sr = new LinearLayout(this);
        sr.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"Econômico", "Normal", "Rápido"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            sb[i] = Ui.button(this, names[i], Ui.DARK, v -> { speed = idx; refresh(); });
            half(sb[i], i == 0 ? 0 : 6);
            sr.addView(sb[i]);
        }
        c2.addView(sr);
        root.addView(c2);

        // ---- Fortnite / xCloud ----
        gameBox = new LinearLayout(this);
        gameBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout c3 = Ui.card(this);
        c3.addView(Ui.text(this, "Sair da partida", 16, Ui.TEXT, true));
        c3.addView(Ui.desc(this, "Tempo máximo por partida, em minutos (0 desliga)."));
        maxmin = Ui.field(this, "Minutos", false);
        maxmin.setInputType(InputType.TYPE_CLASS_NUMBER);
        maxmin.setText(String.valueOf(o.optInt("maxmin", 30)));
        c3.addView(maxmin);
        wipe = new CheckBox(this);
        wipe.setText(I18n.tr("Sair quando todo o time cair"));
        wipe.setTextColor(Ui.TEXT);
        wipe.setChecked(o.optBoolean("wipe", true));
        c3.addView(wipe);
        c3.addView(Ui.desc(this, "No fim da partida, clicar em:"));
        LinearLayout er = new LinearLayout(this);
        er.setOrientation(LinearLayout.HORIZONTAL);
        String[] en = {"Retornar ao lobby", "Jogar novamente"};
        final String[] ek = {"lobby", "again"};
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            eb[i] = Ui.button(this, en[i], Ui.DARK, v -> { endact = ek[idx]; refresh(); });
            half(eb[i], i == 0 ? 0 : 6);
            er.addView(eb[i]);
        }
        c3.addView(er);
        gameBox.addView(c3);
        root.addView(gameBox);

        // ---- macro livre ----
        customBox = new LinearLayout(this);
        customBox.setOrientation(LinearLayout.VERTICAL);
        LinearLayout c4 = Ui.card(this);
        c4.addView(Ui.text(this, "Regras de clique", 16, Ui.TEXT, true));
        c4.addView(Ui.desc(this, "Uma regra por linha, da mais importante para a menos. Em cada linha, separe alternativas com | e o app clica na primeira que aparecer na tela. Ex.: JOGAR NOVAMENTE|RETORNAR AO LOBBY"));
        rules = Ui.field(this, "Ex.: RESGATAR|COLETAR", true);
        rules.setMinLines(5);
        rules.setText(o.optString("rules"));
        c4.addView(rules);
        afk = new CheckBox(this);
        afk.setText(I18n.tr("Mexer o personagem (evitar inatividade)"));
        afk.setTextColor(Ui.TEXT);
        afk.setChecked(o.optBoolean("afk", false));
        c4.addView(afk);
        c4.addView(Ui.desc(this, "O movimento usa o joystick à esquerda e o pulo à direita, como no padrão dos jogos."));
        customBox.addView(c4);
        root.addView(customBox);

        LinearLayout c5 = Ui.card(this);
        c5.addView(Ui.text(this, "Palavras extras para clicar", 16, Ui.TEXT, true));
        c5.addView(Ui.desc(this, "Texto exato de botões que o app não conhece (um por linha)."));
        extra = Ui.field(this, "Ex.: ENTRAR NA FILA", true);
        extra.setText(o.optString("extra"));
        c5.addView(extra);
        root.addView(c5);

        LinearLayout c6 = Ui.card(this);
        c6.addView(Ui.text(this, "Anotações", 16, Ui.TEXT, true));
        c6.addView(Ui.desc(this, "Guarde dicas sobre o jogo ou app."));
        notes = Ui.field(this, "Ex.: o botão de jogar fica no canto direito", true);
        notes.setText(o.optString("notes"));
        c6.addView(notes);
        root.addView(c6);

        root.addView(Ui.button(this, "Salvar", Ui.ACCENT, v -> { save(); finish(); }));
        root.addView(Ui.button(this, "Cancelar", Ui.DARK, v -> finish()));
        setContentView(sv);
        refresh();
    }

    private void half(Button bt, int left) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f);
        lp.setMargins(Ui.dp(this, left), Ui.dp(this, 8), 0, 0);
        bt.setLayoutParams(lp);
    }

    private void refresh() {
        String[] kk = {"fn", "xc", "custom"};
        for (int i = 0; i < 3; i++) {
            kb[i].setBackground(Ui.shape(this, kk[i].equals(kind) ? Ui.ACCENT : Ui.DARK, 12, 0, 0));
            sb[i].setBackground(Ui.shape(this, i == speed ? Ui.ACCENT : Ui.DARK, 12, 0, 0));
        }
        eb[0].setBackground(Ui.shape(this, endact.equals("lobby") ? Ui.ACCENT : Ui.DARK, 12, 0, 0));
        eb[1].setBackground(Ui.shape(this, endact.equals("again") ? Ui.ACCENT : Ui.DARK, 12, 0, 0));
        boolean custom = kind.equals("custom");
        gameBox.setVisibility(custom ? View.GONE : View.VISIBLE);
        customBox.setVisibility(custom ? View.VISIBLE : View.GONE);
    }

    private void save() {
        int mm = 30;
        try { mm = Math.max(0, Math.min(240, Integer.parseInt(maxmin.getText().toString().trim()))); }
        catch (Exception ignored) {}
        try {
            String n = name.getText().toString().trim();
            o.put("name", n.isEmpty() ? "Auto click" : n);
            o.put("kind", kind);
            o.put("extra", extra.getText().toString());
            o.put("maxmin", mm);
            o.put("wipe", wipe.isChecked());
            o.put("speed", speed);
            o.put("endact", endact);
            o.put("rules", rules.getText().toString());
            o.put("afk", afk.isChecked());
            o.put("notes", notes.getText().toString());
        } catch (Exception ignored) {}
        Slots.save(this, all);
        if (o.optString("id").equals(Slots.equippedId(this))) Slots.equip(this, o);
    }
}
