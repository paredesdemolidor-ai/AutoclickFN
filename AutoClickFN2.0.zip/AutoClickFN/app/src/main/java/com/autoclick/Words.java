package com.autoclick;

/** Palavras que o app procura na tela, por idioma (pt, en, es). */
final class Words {
    static final class Set {
        String[] FN_REWARD, FN_AGAIN, FN_RETURN, FN_BACK, FN_EXIT, FN_PLAY, FN_LOBBY, FN_PANEL, FN_DEAD, FN_STATUS, XC_SKIP, XC_PLAYNOW, XC_HOME, XC_WAIT, XC_FEEDBACK, XC_SUBMIT, XC_QUEUE, SMART_OK, SMART_BLOCK, SPEC_WORDS, REBOOT_WORDS, DISCOVER, GOLOBBY, LIBRARY;
        String TAB_PLAY, TAB_LIB, TAB_TREASURE;
    }

    static Set of(String lang) {
        return "en".equals(lang) ? en() : "es".equals(lang) ? es() : pt();
    }


    static Set pt() {
        Set s = new Set();
        s.FN_REWARD = new String[]{"RESGATAR", "COLETAR", "RECEBER", "REIVINDICAR", "CLAIM", "COLLECT", "TOQUE PARA CONTINUAR", "TAP TO CONTINUE", "PRÓXIMO", "PROXIMO", "NEXT", "FECHAR", "CLOSE"};
        s.FN_AGAIN = new String[]{"JOGAR NOVAMENTE", "PLAY AGAIN"};
        s.FN_RETURN = new String[]{"RETORNAR AO LOBBY", "RETURN TO LOBBY"};
        s.FN_BACK = new String[]{"RETORNAR AO LOBBY", "VOLTAR AO LOBBY", "VOLTAR AO SAGUÃO", "VOLTAR AO SAGUAO", "RETURN TO LOBBY"};
        s.FN_EXIT = new String[]{"SAIR DA PARTIDA", "LEAVE MATCH", "CONFIRMAR", "SELECIONAR", "CONTINUAR", "CONTINUE", "SAIR", "SIM", "YES", "OK"};
        s.FN_PLAY = new String[]{"JOGAR", "INICIAR", "PLAY"};
        s.FN_LOBBY = new String[]{"BATE-PAPO", "EQUIPAR UM"};
        s.FN_PANEL = new String[]{"COLEGAS", "SOCIAL", "REGISTRO DE VOZ", "APENAS POR CONVITE"};
        s.FN_DEAD = new String[]{"VOCÊ FOI ELIMINADO", "VOCE FOI ELIMINADO", "YOU WERE ELIMINATED", "VICTORY ROYALE", "VITÓRIA"};
        s.FN_STATUS = new String[]{"DESCONECTADO", "CONECTADO", "ONLINE", "OFFLINE", "AUSENTE"};
        s.XC_SKIP = new String[]{"AGORA NÃO", "AGORA NAO", "NÃO, OBRIGADO", "NAO, OBRIGADO", "NÃO OBRIGADO", "PULAR", "SKIP", "NOT NOW", "NO THANKS", "DISPENSAR", "DISMISS", "MAIS TARDE", "MAYBE LATER", "FECHAR", "CLOSE"};
        s.XC_PLAYNOW = new String[]{"REPRODUZIR AGORA", "PLAY NOW", "JOGAR AGORA"};
        s.XC_HOME = new String[]{"STREAMING GRATUITO", "JOGAR COM AMIGOS", "FREE STREAMING"};
        s.XC_WAIT = new String[]{"INICIANDO O CLOUD", "ANÚNCIO 1 DE", "ANÚNCIO 2 DE", "ANÚNCIO 3 DE", "ANUNCIO 1 DE", "ANUNCIO 2 DE", "ANUNCIO 3 DE", "POSIÇÃO NA FILA", "NA FILA"};
        s.XC_FEEDBACK = new String[]{"COMO FOI", "SUA EXPERIÊNCIA", "SUA EXPERIENCIA", "AVALIE", "PESQUISA", "FEEDBACK", "QUESTIONÁRIO", "QUESTIONARIO", "SURVEY", "SESSÃO ENCERRADA", "SESSÃO TERMINOU", "SESSION ENDED", "AVALIAÇÃO", "AVALIE A PARTIDA", "GOSTOU DA PARTIDA", "QUESTIONÁRIO"};
        s.XC_SUBMIT = new String[]{"ENVIAR", "SUBMIT", "CONCLUIR", "FEITO", "DONE", "SEGUINTE", "PRÓXIMO", "PROXIMO", "NEXT"};
        s.XC_QUEUE = new String[]{"ENTRAR NA FILA", "JOIN QUEUE", "JOGAR NOVAMENTE", "PLAY AGAIN", "TENTAR NOVAMENTE", "TRY AGAIN", "RECONECTAR", "RECONNECT"};
        s.SMART_OK = new String[]{"PULAR", "SKIP", "AGORA NÃO", "AGORA NAO", "NÃO, OBRIGADO", "NAO, OBRIGADO", "MAIS TARDE", "DEPOIS", "FECHAR", "CLOSE", "ENTENDI", "OK", "CONTINUAR", "CONTINUE", "PRÓXIMO", "NEXT", "ACEITAR", "ACEITO", "CONCORDO", "CONFIRMAR", "TENTAR NOVAMENTE", "RECONECTAR", "INICIAR", "REPRODUZIR"};
        s.SMART_BLOCK = new String[]{"COMPRAR", "COMPRA", "ASSINAR", "ASSINATURA", "ADQUIRIR", "PAGAR", "PREÇO", "PRECO", "R$", "V-BUCKS", "COMPARE OS PLANOS", "UPGRADE", "EXCLUIR", "DENUNCIAR", "DESCONECTAR", "SAIR DA CONTA"};
        s.SPEC_WORDS = new String[]{"ESPECTADOR", "SPECTATOR"};
        s.REBOOT_WORDS = new String[]{"PROCESSANDO REINICIALIZA", "PROCESSING REBOOT"};
        s.DISCOVER = new String[]{"IR PARA O LOBBY", "CHAVE PERSONALIZADA"};
        s.GOLOBBY = new String[]{"IR PARA O LOBBY"};
        s.LIBRARY = new String[]{"BIBLIOTECA"};
        s.TAB_PLAY = "JOGAR";
        s.TAB_LIB = "BIBLIOTECA";
        s.TAB_TREASURE = "TESOURO";
        return s;
    }

    static Set en() {
        Set s = pt();
        s.FN_REWARD = new String[]{"CLAIM", "COLLECT", "RECEIVE", "REDEEM", "TAP TO CONTINUE", "NEXT", "CLOSE"};
        s.FN_AGAIN = new String[]{"PLAY AGAIN"};
        s.FN_RETURN = new String[]{"RETURN TO LOBBY"};
        s.FN_BACK = new String[]{"RETURN TO LOBBY"};
        s.FN_EXIT = new String[]{"LEAVE MATCH", "CONFIRM", "SELECT", "CONTINUE", "LEAVE", "YES", "OK"};
        s.FN_PLAY = new String[]{"PLAY", "START"};
        s.FN_LOBBY = new String[]{"CHAT", "EQUIP AN ELEMENTAL", "PARTY CHAT"};
        s.FN_PANEL = new String[]{"FRIENDS", "SOCIAL", "VOICE CHAT", "INVITE ONLY"};
        s.FN_DEAD = new String[]{"YOU WERE ELIMINATED", "VICTORY ROYALE", "VICTORY"};
        s.FN_STATUS = new String[]{"OFFLINE", "ONLINE", "AWAY"};
        s.SPEC_WORDS = new String[]{"SPECTATING", "SPECTATOR"};
        s.REBOOT_WORDS = new String[]{"PROCESSING REBOOT", "PROCESSING REDEPLOY"};
        s.XC_SKIP = new String[]{"SKIP", "NOT NOW", "NO THANKS", "DISMISS", "MAYBE LATER", "CLOSE"};
        s.XC_PLAYNOW = new String[]{"PLAY NOW", "PLAY WITH ADS"};
        s.XC_HOME = new String[]{"FREE STREAMING", "PLAY WITH FRIENDS"};
        s.XC_WAIT = new String[]{"STARTING CLOUD GAMING", "AD 1 OF", "AD 2 OF", "AD 3 OF", "QUEUE POSITION", "IN QUEUE"};
        s.XC_FEEDBACK = new String[]{"HOW WAS", "YOUR EXPERIENCE", "RATE", "SURVEY", "FEEDBACK", "SESSION ENDED", "RATE THIS MATCH", "MATCH RATING", "DID YOU ENJOY", "QUESTIONNAIRE"};
        s.XC_SUBMIT = new String[]{"SUBMIT", "DONE", "NEXT"};
        s.XC_QUEUE = new String[]{"JOIN QUEUE", "PLAY AGAIN", "TRY AGAIN", "RECONNECT"};
        s.SMART_OK = new String[]{"SKIP", "NOT NOW", "NO THANKS", "LATER", "CLOSE", "GOT IT", "OK", "CONTINUE", "NEXT", "ACCEPT", "AGREE", "CONFIRM", "TRY AGAIN", "RECONNECT", "START", "PLAY"};
        s.SMART_BLOCK = new String[]{"BUY", "PURCHASE", "SUBSCRIBE", "SUBSCRIPTION", "PRICE", "V-BUCKS", "COMPARE PLANS", "UPGRADE", "DELETE", "REPORT", "DISCONNECT", "SIGN OUT"};
        s.DISCOVER = new String[]{"GO TO LOBBY", "CUSTOM KEY"};
        s.GOLOBBY = new String[]{"GO TO LOBBY"};
        s.LIBRARY = new String[]{"LIBRARY"};
        s.TAB_PLAY = "PLAY";
        s.TAB_LIB = "LIBRARY";
        s.TAB_TREASURE = "TREASURE";
        return s;
    }

    static Set es() {
        Set s = pt();
        s.FN_REWARD = new String[]{"RECLAMAR", "RECOGER", "RECIBIR", "CANJEAR", "TOCA PARA CONTINUAR", "SIGUIENTE", "CERRAR"};
        s.FN_AGAIN = new String[]{"JUGAR DE NUEVO", "VOLVER A JUGAR"};
        s.FN_RETURN = new String[]{"VOLVER AL LOBBY", "REGRESAR AL LOBBY"};
        s.FN_BACK = new String[]{"VOLVER AL LOBBY", "REGRESAR AL LOBBY"};
        s.FN_EXIT = new String[]{"ABANDONAR PARTIDA", "SALIR DE LA PARTIDA", "CONFIRMAR", "SELECCIONAR", "CONTINUAR", "SALIR", "SÍ", "OK"};
        s.FN_PLAY = new String[]{"JUGAR", "INICIAR", "EMPEZAR"};
        s.FN_LOBBY = new String[]{"CHAT", "EQUIPA UN ELEMENTAL", "CHAT DE GRUPO"};
        s.FN_PANEL = new String[]{"AMIGOS", "SOCIAL", "CHAT DE VOZ", "SOLO CON INVITACIÓN"};
        s.FN_DEAD = new String[]{"FUISTE ELIMINADO", "VICTORIA MAGISTRAL", "VICTORIA"};
        s.FN_STATUS = new String[]{"DESCONECTADO", "EN LÍNEA", "AUSENTE"};
        s.SPEC_WORDS = new String[]{"MODO ESPECTADOR", "ESPECTADOR"};
        s.REBOOT_WORDS = new String[]{"PROCESANDO REINICIO", "PROCESANDO REINICIALIZACIÓN"};
        s.XC_SKIP = new String[]{"OMITIR", "AHORA NO", "NO, GRACIAS", "NO GRACIAS", "DESCARTAR", "MÁS TARDE", "CERRAR"};
        s.XC_PLAYNOW = new String[]{"REPRODUCIR AHORA", "JUGAR AHORA"};
        s.XC_HOME = new String[]{"STREAMING GRATIS", "JUGAR CON AMIGOS"};
        s.XC_WAIT = new String[]{"INICIANDO CLOUD GAMING", "ANUNCIO 1 DE", "ANUNCIO 2 DE", "ANUNCIO 3 DE", "POSICIÓN EN LA COLA", "EN COLA"};
        s.XC_FEEDBACK = new String[]{"CÓMO FUE", "TU EXPERIENCIA", "VALORA", "ENCUESTA", "COMENTARIOS", "SESIÓN FINALIZADA", "VALORA LA PARTIDA", "¿TE GUSTÓ", "CUESTIONARIO", "EVALUACIÓN"};
        s.XC_SUBMIT = new String[]{"ENVIAR", "LISTO", "SIGUIENTE"};
        s.XC_QUEUE = new String[]{"UNIRSE A LA COLA", "JUGAR DE NUEVO", "REINTENTAR", "RECONECTAR"};
        s.SMART_OK = new String[]{"OMITIR", "AHORA NO", "NO, GRACIAS", "MÁS TARDE", "CERRAR", "ENTENDIDO", "OK", "CONTINUAR", "SIGUIENTE", "ACEPTAR", "ACEPTO", "CONFIRMAR", "REINTENTAR", "RECONECTAR", "INICIAR", "REPRODUCIR"};
        s.SMART_BLOCK = new String[]{"COMPRAR", "SUSCRIBIRSE", "SUSCRIPCIÓN", "PAGAR", "PRECIO", "V-BUCKS", "COMPARAR PLANES", "ELIMINAR", "DENUNCIAR", "DESCONECTAR", "CERRAR SESIÓN"};
        s.DISCOVER = new String[]{"IR AL LOBBY", "CLAVE PERSONALIZADA"};
        s.GOLOBBY = new String[]{"IR AL LOBBY"};
        s.LIBRARY = new String[]{"BIBLIOTECA"};
        s.TAB_PLAY = "JUGAR";
        s.TAB_LIB = "BIBLIOTECA";
        s.TAB_TREASURE = "TESORO";
        return s;
    }

}
