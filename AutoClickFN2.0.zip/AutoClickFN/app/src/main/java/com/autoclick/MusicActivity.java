package com.autoclick;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class MusicActivity extends Activity {
    private static final int REQ = 31;
    private DiscView disc;
    private TextView titleTv, artistTv, timeTv, srcTv;
    private SeekBar seek;
    private BaseAdapter adapter;
    private final Handler h = new Handler(Looper.getMainLooper());
    private String artKey = "";
    private boolean seeking = false, curInternal = true;
    private int curDur = 0;
    private final Runnable tick = new Runnable() {
        @Override public void run() { refresh(); h.postDelayed(this, 400); }
    };

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        int p = Ui.dp(this, 16);
        root.setPadding(p, Ui.dp(this, 24), p, p);
        root.addView(Ui.header(this, "Música"));
        srcTv = Ui.desc(this, "");
        srcTv.setGravity(Gravity.CENTER);
        root.addView(srcTv);

        disc = new DiscView(this);
        root.addView(disc, new LinearLayout.LayoutParams(-1, Ui.dp(this, 200)));

        titleTv = Ui.text(this, "Nada tocando", 18, Ui.TEXT, true);
        titleTv.setGravity(Gravity.CENTER);
        titleTv.setSingleLine(true);
        titleTv.setEllipsize(TextUtils.TruncateAt.END);
        root.addView(titleTv);
        artistTv = Ui.desc(this, "");
        artistTv.setGravity(Gravity.CENTER);
        root.addView(artistTv);

        seek = new SeekBar(this);
        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int pr, boolean fromUser) {
                if (fromUser) timeTv.setText(fmt(pr) + " / " + fmt(curDur));
            }
            @Override public void onStartTrackingTouch(SeekBar sb) { seeking = true; }
            @Override public void onStopTrackingTouch(SeekBar sb) {
                seeking = false;
                MusicCtl.seek(MusicActivity.this, curInternal, sb.getProgress());
            }
        });
        root.addView(seek);
        timeTv = Ui.desc(this, "0:00 / 0:00");
        timeTv.setGravity(Gravity.CENTER);
        root.addView(timeTv);

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        String[] names = {"«", "▶ / ❚❚", "»"};
        for (int i = 0; i < 3; i++) {
            final int idx = i;
            Button bt = Ui.button(this, names[i], Ui.ACCENT, v -> {
                if (idx == 0) MusicCtl.prev(this); else if (idx == 1) MusicCtl.toggle(this); else MusicCtl.next(this);
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 46), 1f);
            lp.setMargins(i == 0 ? 0 : Ui.dp(this, 6), Ui.dp(this, 8), 0, 0);
            bt.setLayoutParams(lp);
            row.addView(bt);
        }
        root.addView(row);

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        Button sh = Ui.button(this, "Aleatório (tudo)", Ui.DARK, v -> {
            if (MusicService.ALL.isEmpty()) toast("Nenhuma música encontrada"); else MusicService.playQueue(this, -1, true);
        });
        Button ac = Ui.button(this, "Outros apps", Ui.DARK, v -> {
            try { startActivity(new Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS")); }
            catch (Exception e) { toast("Abra Configurações > Notificações > Acesso a notificações"); }
        });
        for (int i = 0; i < 2; i++) {
            Button bt = i == 0 ? sh : ac;
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, Ui.dp(this, 44), 1f);
            lp.setMargins(i == 0 ? 0 : Ui.dp(this, 6), Ui.dp(this, 8), 0, Ui.dp(this, 8));
            bt.setLayoutParams(lp);
            row2.addView(bt);
        }
        root.addView(row2);
        root.addView(Ui.desc(this, "\"Outros apps\": libere o acesso às notificações para o NexMacro mostrar e controlar o que toca no Spotify, YouTube Music etc."));

        ListView list = new ListView(this);
        list.setDividerHeight(0);
        list.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return MusicService.ALL.size(); }
            @Override public Object getItem(int i) { return MusicService.ALL.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View cv, ViewGroup parent) {
                LinearLayout rw;
                if (cv == null) {
                    rw = new LinearLayout(MusicActivity.this);
                    rw.setOrientation(LinearLayout.VERTICAL);
                    int pd = Ui.dp(MusicActivity.this, 10);
                    rw.setPadding(pd, pd, pd, pd);
                    TextView t1 = Ui.text(MusicActivity.this, "", 15, Ui.TEXT, true);
                    t1.setSingleLine(true);
                    t1.setEllipsize(TextUtils.TruncateAt.END);
                    TextView t2 = Ui.desc(MusicActivity.this, "");
                    t2.setSingleLine(true);
                    rw.addView(t1);
                    rw.addView(t2);
                    rw.setTag(new TextView[]{t1, t2});
                } else {
                    rw = (LinearLayout) cv;
                }
                TextView[] tv = (TextView[]) rw.getTag();
                MusicService.Track t = MusicService.ALL.get(i);
                tv[0].setText(t.title);
                tv[1].setText(t.artist);
                return rw;
            }
        };
        list.setAdapter(adapter);
        list.setOnItemClickListener((pa, v, pos, id) -> MusicService.playQueue(this, pos, false));
        root.addView(list);
        setContentView(root);
        ensurePermission();
    }

    private void ensurePermission() {
        String perm = Build.VERSION.SDK_INT >= 33 ? Manifest.permission.READ_MEDIA_AUDIO : Manifest.permission.READ_EXTERNAL_STORAGE;
        if (checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) loadAll();
        else requestPermissions(new String[]{perm}, REQ);
    }

    @Override
    public void onRequestPermissionsResult(int req, String[] perms, int[] res) {
        super.onRequestPermissionsResult(req, perms, res);
        if (req == REQ) {
            if (res.length > 0 && res[0] == PackageManager.PERMISSION_GRANTED) loadAll();
            else toast("Sem permissão para ler suas músicas");
        }
    }

    private void loadAll() {
        new Thread(() -> {
            MusicService.load(this);
            runOnUiThread(() -> adapter.notifyDataSetChanged());
        }).start();
    }

    private void refresh() {
        MusicCtl.Info in = MusicCtl.info(this);
        curInternal = in.internal;
        titleTv.setText(in.title);
        artistTv.setText(in.artist);
        srcTv.setText(in.hasSource ? (in.internal ? "Tocando neste app" : "Tocando em outro app")
                : "Escolha uma música abaixo ou toque em outro app de música");
        disc.setPlaying(in.playing);
        curDur = Math.max(in.dur, 0);
        seek.setMax(Math.max(curDur, 1));
        if (!seeking) {
            seek.setProgress(Math.min(in.pos, Math.max(curDur, 1)));
            timeTv.setText(fmt(in.pos) + " / " + fmt(curDur));
        }
        if (!in.key.equals(artKey)) {
            artKey = in.key;
            if (in.internal && in.track != null) {
                final MusicService.Track t = in.track;
                final String key = in.key;
                new Thread(() -> {
                    final Bitmap bm = MusicService.art(this, t, 512);
                    runOnUiThread(() -> { if (key.equals(artKey)) disc.setArt(bm); });
                }).start();
            } else {
                disc.setArt(in.extArt);
            }
        }
    }

    private String fmt(int ms) {
        int s = Math.max(0, ms) / 1000;
        return (s / 60) + ":" + (s % 60 < 10 ? "0" : "") + (s % 60);
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }

    @Override
    protected void onResume() {
        super.onResume();
        h.post(tick);
    }

    @Override
    protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }
}
