package com.autoclick;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.drawable.Icon;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.IBinder;
import android.provider.MediaStore;
import android.util.Size;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/** Toca as musicas do celular em segundo plano (notificacao com controles). */
public class MusicService extends Service {
    static final class Track {
        final long id, dur;
        final String title, artist;
        Track(long id, String title, String artist, long dur) {
            this.id = id;
            this.title = title == null ? "Sem título" : title;
            this.artist = artist == null || artist.equals("<unknown>") ? "Artista desconhecido" : artist;
            this.dur = dur;
        }
        Uri uri() { return ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, id); }
    }

    private static final int NOTIF = 31;
    static MusicService instance;
    static final List<Track> ALL = new ArrayList<>();
    static final List<Track> QUEUE = new ArrayList<>();
    static int index = -1;

    private MediaPlayer mp;
    private boolean prepared = false;
    private int failStreak = 0;

    // ---------- estado / biblioteca ----------
    static boolean hasTrack() { return index >= 0 && index < QUEUE.size(); }
    static Track current() { return hasTrack() ? QUEUE.get(index) : null; }
    static boolean isPlaying() {
        try { return instance != null && instance.mp != null && instance.prepared && instance.mp.isPlaying(); }
        catch (Exception e) { return false; }
    }
    static int position() {
        try { return instance != null && instance.mp != null && instance.prepared ? instance.mp.getCurrentPosition() : 0; }
        catch (Exception e) { return 0; }
    }
    static int duration() {
        try { return instance != null && instance.mp != null && instance.prepared ? instance.mp.getDuration() : 0; }
        catch (Exception e) { return 0; }
    }
    static void seekTo(int ms) {
        try { if (instance != null && instance.mp != null && instance.prepared) instance.mp.seekTo(ms); }
        catch (Exception ignored) {}
    }

    static void load(Context c) {
        List<Track> tmp = new ArrayList<>();
        String[] proj = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.DURATION};
        String sel = MediaStore.Audio.Media.IS_MUSIC + "!=0 AND " + MediaStore.Audio.Media.DURATION + ">30000";
        try (Cursor cur = c.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, proj, sel, null,
                MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            if (cur != null) while (cur.moveToNext()) tmp.add(new Track(cur.getLong(0), cur.getString(1), cur.getString(2), cur.getLong(3)));
        } catch (Exception ignored) {}
        ALL.clear();
        ALL.addAll(tmp);
    }

    static Bitmap art(Context c, Track t, int px) {
        if (t == null) return null;
        try { return c.getContentResolver().loadThumbnail(t.uri(), new Size(px, px), null); }
        catch (Exception e) { return null; }
    }

    /** Monta a fila (opcionalmente embaralhada) e comeca a tocar. */
    static void playQueue(Context c, int startInAll, boolean shuffle) {
        if (ALL.isEmpty()) return;
        QUEUE.clear();
        QUEUE.addAll(ALL);
        if (shuffle) {
            Track first = startInAll >= 0 && startInAll < ALL.size() ? ALL.get(startInAll) : null;
            Collections.shuffle(QUEUE);
            if (first != null) { QUEUE.remove(first); QUEUE.add(0, first); }
            index = 0;
        } else {
            index = Math.max(0, Math.min(startInAll, QUEUE.size() - 1));
        }
        c.startForegroundService(new Intent(c, MusicService.class).setAction("play"));
    }

    // ---------- controles ----------
    static void toggleNow() { if (instance != null) instance.toggle(); }
    static void nextNow() { if (instance != null) instance.next(); }
    static void prevNow() { if (instance != null) instance.prev(); }

    // ---------- servico ----------
    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        nm.createNotificationChannel(new NotificationChannel("music", "Música", NotificationManager.IMPORTANCE_LOW));
    }

    @Override
    public int onStartCommand(Intent i, int flags, int startId) {
        startForeground(NOTIF, buildNotification());
        String a = i == null ? null : i.getAction();
        if ("play".equals(a)) playCurrent();
        else if ("toggle".equals(a)) toggle();
        else if ("next".equals(a)) next();
        else if ("prev".equals(a)) prev();
        else if ("stop".equals(a)) { stopForeground(true); stopSelf(); }
        return START_NOT_STICKY;
    }

    private void playCurrent() {
        Track t = current();
        if (t == null) { stopForeground(true); stopSelf(); return; }
        try {
            if (mp == null) {
                mp = new MediaPlayer();
                mp.setAudioAttributes(new AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            }
            mp.reset();
            prepared = false;
            mp.setDataSource(this, t.uri());
            mp.setOnPreparedListener(m -> { prepared = true; failStreak = 0; m.start(); updateNotif(); });
            mp.setOnCompletionListener(m -> next());
            mp.setOnErrorListener((m, what, extra) -> { fail(); return true; });
            mp.prepareAsync();
        } catch (Exception e) {
            fail();
        }
        updateNotif();
    }

    private void fail() {
        if (++failStreak > 5) { stopForeground(true); stopSelf(); return; }
        next();
    }

    private void toggle() {
        if (mp != null && prepared) {
            try { if (mp.isPlaying()) mp.pause(); else mp.start(); } catch (Exception ignored) {}
            updateNotif();
        } else if (hasTrack()) {
            playCurrent();
        }
    }

    private void next() {
        if (QUEUE.isEmpty()) return;
        index = (index + 1) % QUEUE.size();
        playCurrent();
    }

    private void prev() {
        if (QUEUE.isEmpty()) return;
        if (position() > 3000) { seekTo(0); return; }
        index = (index - 1 + QUEUE.size()) % QUEUE.size();
        playCurrent();
    }

    private PendingIntent svc(String action) {
        return PendingIntent.getService(this, action.hashCode(), new Intent(this, MusicService.class).setAction(action),
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
    }

    private Notification.Action act(int icon, String title, String action) {
        return new Notification.Action.Builder(Icon.createWithResource(this, icon), title, svc(action)).build();
    }

    private Notification buildNotification() {
        Track t = current();
        Notification.Builder b = new Notification.Builder(this, "music")
                .setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle(t == null ? "NexMacro Música" : t.title)
                .setContentText(t == null ? "" : t.artist)
                .setContentIntent(PendingIntent.getActivity(this, 0, new Intent(this, MusicActivity.class), PendingIntent.FLAG_IMMUTABLE))
                .addAction(act(android.R.drawable.ic_media_previous, "Anterior", "prev"))
                .addAction(act(isPlaying() ? android.R.drawable.ic_media_pause : android.R.drawable.ic_media_play, "Play/Pausa", "toggle"))
                .addAction(act(android.R.drawable.ic_media_next, "Próxima", "next"))
                .setStyle(new Notification.MediaStyle().setShowActionsInCompactView(0, 1, 2));
        Bitmap art = art(this, t, 256);
        if (art != null) b.setLargeIcon(art);
        return b.build();
    }

    private void updateNotif() {
        try {
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).notify(NOTIF, buildNotification());
        } catch (Exception ignored) {}
    }

    @Override
    public void onDestroy() {
        if (mp != null) { try { mp.release(); } catch (Exception ignored) {} mp = null; }
        prepared = false;
        if (instance == this) instance = null;
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent i) { return null; }
}
