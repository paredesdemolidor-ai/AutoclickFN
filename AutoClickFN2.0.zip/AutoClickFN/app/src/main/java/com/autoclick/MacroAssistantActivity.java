package com.autoclick;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

public class MacroAssistantActivity extends Activity {
    private EditText game, goal, extra;
    private LinearLayout result;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        ScrollView sv = new ScrollView(this);
        sv.setBackgroundColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 16);
        root.setPadding(p, Ui.dp(this, 24), p, p);
        sv.addView(root);
        root.addView(Ui.header(this, "Assistente de macros"));
        root.addView(Ui.desc(this, "Diga o jogo e para que o macro serve. O assistente (offline) monta as regras com o que ele sabe, e você ajusta depois."));

        LinearLayout c = Ui.card(this);
        c.addView(Ui.text(this, "Jogo ou app", 16, Ui.TEXT, true));
        game = Ui.field(this, "Ex.: Call of Duty Mobile", false);
        c.addView(game);
        c.addView(Ui.text(this, "Para que serve o macro?", 16, Ui.TEXT, true));
        c.addView(Ui.desc(this, "Ex.: ficar afk nas partidas, jogar partidas em loop, resgatar recompensas, pular anúncios."));
        goal = Ui.field(this, "Descreva o que o macro deve fazer", true);
        c.addView(goal);
        c.addView(Ui.text(this, "Palavras extras (opcional)", 16, Ui.TEXT, true));
        c.addView(Ui.desc(this, "Textos de botões do jogo que você já conhece, um por linha. Eles são clicados primeiro."));
        extra = Ui.field(this, "Ex.: PARTIDA RÁPIDA", true);
        c.addView(extra);
        c.addView(Ui.button(this, "Gerar macro", Ui.ACCENT, v -> generate()));
        root.addView(c);

        result = Ui.card(this);
        result.setVisibility(android.view.View.GONE);
        root.addView(result);
        setContentView(sv);
    }

    private void generate() {
        StringBuilder sum = new StringBuilder();
        final JSONObject macro = MacroDb.generate(game.getText().toString(), goal.getText().toString(),
                extra.getText().toString(), sum, I18n.lang);
        result.removeAllViews();
        result.setVisibility(android.view.View.VISIBLE);
        result.addView(Ui.text(this, macro.optString("name"), 17, Ui.OK, true));
        TextView t = Ui.desc(this, sum.toString());
        result.addView(t);
        result.addView(Ui.button(this, "Salvar e editar", Ui.ACCENT, v -> {
            if (Slots.addJson(this, macro)) {
                startActivity(new Intent(this, SlotEditActivity.class).putExtra("id", macro.optString("id")));
                finish();
            } else {
                Toast.makeText(this, "Limite de 5 auto clicks: exclua um primeiro", Toast.LENGTH_LONG).show();
            }
        }));
    }
}
