package com.autoclick;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/** Disco de vinil girando com a capa da musica. */
public class DiscView extends View {
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path clip = new Path();
    private Bitmap art;
    private boolean playing;
    private float angle;
    private long last = System.nanoTime();

    public DiscView(Context c) { super(c); }

    void setArt(Bitmap b) { art = b; invalidate(); }

    void setPlaying(boolean v) {
        if (v && !playing) { last = System.nanoTime(); }
        playing = v;
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        long now = System.nanoTime();
        float dt = (now - last) / 1e9f;
        last = now;
        if (playing) angle = (angle + dt * 40f) % 360f;

        float w = getWidth(), h = getHeight();
        float cx = w / 2f, cy = h / 2f;
        float r = Math.min(w, h) / 2f - 6 * getResources().getDisplayMetrics().density;

        p.setStyle(Paint.Style.FILL);
        p.setShader(new RadialGradient(cx, cy, r * 1.2f,
                new int[]{(Ui.ACCENT & 0x00FFFFFF) | 0x66000000, 0x00000000}, null, Shader.TileMode.CLAMP));
        c.drawCircle(cx, cy, r * 1.2f, p);
        p.setShader(null);

        c.save();
        c.rotate(angle, cx, cy);
        p.setColor(0xFF0B0B10);
        c.drawCircle(cx, cy, r, p);
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1f);
        p.setColor(0x26FFFFFF);
        for (float k = 0.66f; k < 0.99f; k += 0.055f) c.drawCircle(cx, cy, r * k, p);

        float ar = r * 0.58f;
        p.setStyle(Paint.Style.FILL);
        if (art != null) {
            clip.reset();
            clip.addCircle(cx, cy, ar, Path.Direction.CW);
            c.save();
            c.clipPath(clip);
            int side = Math.min(art.getWidth(), art.getHeight());
            Rect src = new Rect((art.getWidth() - side) / 2, (art.getHeight() - side) / 2,
                    (art.getWidth() + side) / 2, (art.getHeight() + side) / 2);
            c.drawBitmap(art, src, new RectF(cx - ar, cy - ar, cx + ar, cy + ar), p);
            c.restore();
        } else {
            p.setColor(Ui.ACCENT);
            c.drawCircle(cx, cy, ar, p);
        }
        p.setColor(0xFF0F1220);
        c.drawCircle(cx, cy, r * 0.07f, p);
        c.restore();

        if (playing) postInvalidateOnAnimation();
    }
}
