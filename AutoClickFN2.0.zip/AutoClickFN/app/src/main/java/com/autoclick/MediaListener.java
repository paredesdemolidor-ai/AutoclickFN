package com.autoclick;

import android.service.notification.NotificationListenerService;

/** Vazio de proposito: so serve para o Android liberar a leitura das sessoes de midia (outros apps de musica). */
public class MediaListener extends NotificationListenerService {
}
