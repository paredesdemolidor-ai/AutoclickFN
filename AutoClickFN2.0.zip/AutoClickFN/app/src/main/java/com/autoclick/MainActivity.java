package com.autoclick;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.InputStream;

public class MainActivity extends Activity {
    private static final String YT = "https://www.youtube.com/@naoseicomocolocaonome_dasilva";
    private static final String TT = "https://www.tiktok.com/@palhaco.do.bem";
    private static final int REQ_BG = 21;
    private static final int[] COLORS = {0xFF7C4DFF, 0xFF00E5FF, 0xFF3DDC84, 0xFFFF4081, 0xFFFF9100, 0xFFE5484D};

    private SharedPreferences sp;
    private EditText nick, hold;
    private TextView nickAuto, statusTv, equippedTv;
    private HorizontalScrollView hs;
    private final TextView[] tabs = new TextView[2];
    private int pageW, page = 0;
    private String shownLang;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);
        I18n.init(this);
        shownLang = I18n.lang;
        Ui.ACCENT = sp.getInt("accent", 0xFF7C4DFF);
        Slots.ensure(this);
        final boolean studio = BuildConfig.STUDIO;
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);

        if (Build.VERSION.SDK_INT >= 33 && !sp.getBoolean("askedNotif", false)
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            sp.edit().putBoolean("askedNotif", true).apply();
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 11);
        }

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = Ui.dp(this, 18);
        root.setPadding(p, Ui.dp(this, 24), p, 0);

        // ---- capa animada (nome no meio) ----
        FrameLayout banner = new FrameLayout(this);
        banner.setBackground(Ui.shape(this, 0xFF05060D, 22, 0, 0));
        banner.setClipToOutline(true);
        banner.addView(new GlowView(this), new FrameLayout.LayoutParams(-1, -1));
        LinearLayout tl = new LinearLayout(this);
        tl.setOrientation(LinearLayout.VERTICAL);
        tl.setGravity(Gravity.CENTER);
        TextView title = Ui.text(this, getString(R.string.app_name), 30, Ui.TEXT, true);
        title.setLetterSpacing(0.08f);
        title.setGravity(Gravity.CENTER);
        title.setShadowLayer(22f, 0, 0, Ui.CYAN);
        tl.addView(title);
        TextView sub = Ui.text(this, I18n.greeting() + "! " + I18n.tr("Macros de toque para jogos e apps"), 13, Ui.MUTED, false);
        sub.setGravity(Gravity.CENTER);
        tl.addView(sub);
        banner.addView(tl, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams blp = new LinearLayout.LayoutParams(-1, Ui.dp(this, 150));
        blp.setMargins(0, 0, 0, Ui.dp(this, 10));
        root.addView(banner, blp);

        // ---- abas (so na edicao Studio) ----
        LinearLayout tabRow = new LinearLayout(this);
        tabRow.setOrientation(LinearLayout.HORIZONTAL);
        String[] tn = {"Macros", "Estúdio e mais"};
        for (int i = 0; i < 2; i++) {
            final int idx = i;
            TextView t = Ui.text(this, tn[i], 14, Ui.TEXT, true);
            t.setGravity(Gravity.CENTER);
            t.setPadding(0, Ui.dp(this, 10), 0, Ui.dp(this, 10));
            LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0, -2, 1f);
            tp.setMargins(i == 0 ? 0 : Ui.dp(this, 6), 0, 0, Ui.dp(this, 8));
            t.setLayoutParams(tp);
            t.setOnClickListener(v -> goPage(idx));
            Ui.pressable(t);
            tabs[i] = t;
            tabRow.addView(t);
        }
        if (studio) root.addView(tabRow);

        // ---- paginas (arraste para o lado) ----
        pageW = getResources().getDisplayMetrics().widthPixels - 2 * p;
        hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        LinearLayout pages = new LinearLayout(this);
        pages.setOrientation(LinearLayout.HORIZONTAL);
        hs.addView(pages);
        hs.setOnTouchListener((v, e) -> {
            if (studio && (e.getAction() == MotionEvent.ACTION_UP || e.getAction() == MotionEvent.ACTION_CANCEL))
                hs.postDelayed(() -> goPage(Math.round(hs.getScrollX() / (float) pageW)), 90);
            return false;
        });
        LinearLayout p1 = newPage(pages);
        LinearLayout p2 = studio ? newPage(pages) : null;
        root.addView(hs);

        // =============== PAGINA 1: MACROS ===============
        LinearLayout st = Ui.card(this);
        statusTv = Ui.text(this, "", 17, Ui.TEXT, true);
        st.addView(statusTv);
        st.addView(Ui.desc(this, "Ative o serviço de acessibilidade para o app tocar na tela e ler botões. Tudo acontece no seu aparelho."));
        st.addView(Ui.button(this, "Abrir acessibilidade", Ui.ACCENT,
                v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))));
        p1.addView(st);

        p1.addView(Ui.section(this, "Auto clicks"));
        LinearLayout ac = Ui.card(this);
        ac.addView(Ui.text(this, "Equipado agora", 13, Ui.MUTED, false));
        equippedTv = Ui.text(this, "", 20, Ui.TEXT, true);
        ac.addView(equippedTv);
        ac.addView(Ui.desc(this, "Até 5 macros, cada um com nome, tempo, palavras extras e anotações. Equipe um e dê play pela bolinha flutuante."));
        ac.addView(Ui.button(this, "Gerenciar auto clicks", Ui.ACCENT,
                v -> startActivity(new Intent(this, SlotsActivity.class))));
        if (studio) {
            ac.addView(Ui.button(this, "Criar macro com assistente", Ui.DARK,
                    v -> startActivity(new Intent(this, MacroAssistantActivity.class))));
        }
        p1.addView(ac);

        p1.addView(Ui.section(this, "Ajustes"));
        LinearLayout c1 = Ui.card(this);
        c1.addView(Ui.text(this, "Seu nick no Fortnite", 16, Ui.TEXT, true));
        c1.addView(Ui.desc(this, "Usado para não confundir você com um companheiro ao olhar a barra do time. Deixe vazio para ler sozinho no lobby."));
        nick = Ui.field(this, "Ex.: SeuNick", false);
        nick.setText(sp.getString("nick", ""));
        c1.addView(nick);
        nickAuto = Ui.desc(this, "");
        c1.addView(nickAuto);
        p1.addView(c1);

        LinearLayout lc = Ui.card(this);
        lc.addView(Ui.text(this, "Idioma do app e do jogo", 16, Ui.TEXT, true));
        lc.addView(Ui.desc(this, "Define o idioma do app e como ele lê os textos do jogo."));
        lc.addView(Ui.button(this, "Alterar idioma", Ui.DARK,
                v -> startActivity(new Intent(this, LanguageActivity.class).putExtra("settings", true))));
        p1.addView(lc);

        p1.addView(Ui.section(this, "Bolinha flutuante"));
        LinearLayout c2 = Ui.card(this);
        c2.addView(Ui.text(this, "Menu em roda", 16, Ui.TEXT, true));
        c2.addView(Ui.desc(this, studio
                ? "Toque na bolinha: Play/Stop, próximo macro, Editar (muda o macro sem abrir o app), Música, Desenhar na tela, Ocultar, App e Desligar. Arraste para mover e solte na lixeira para ocultar (uma notificação traz de volta)."
                : "Toque na bolinha: Play/Stop, próximo macro, Editar (muda o macro sem abrir o app), Ocultar, App e Desligar. Arraste para mover e solte na lixeira para ocultar (uma notificação traz de volta)."));
        c2.addView(Ui.desc(this, "Segurar para abrir (segundos, 0 = só tocar):"));
        hold = Ui.field(this, "0", false);
        hold.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
        hold.setText(String.valueOf(sp.getFloat("holdsec", 0f)));
        c2.addView(hold);
        c2.addView(Ui.button(this, "Mostrar bolinha", Ui.DARK, v -> {
            if (ClickService.instance != null) ClickService.instance.setOverlayVisible(true);
            else toast("Ative o serviço em Acessibilidade primeiro");
        }));
        c2.addView(Ui.button(this, "Esconder bolinha", Ui.DARK, v -> {
            if (ClickService.instance != null) ClickService.instance.setOverlayVisible(false);
            else toast("O serviço não está ativo");
        }));
        p1.addView(c2);

        p1.addView(Ui.section(this, "Sistema"));
        LinearLayout c4 = Ui.card(this);
        c4.addView(Ui.text(this, "Otimização", 16, Ui.TEXT, true));
        c4.addView(Ui.desc(this, "Para rodar liso: feche outros apps, deixe a bateria sem restrição para o app, use a velocidade Econômico em sessões longas e mantenha o jogo em tela cheia e deitado."));
        c4.addView(Ui.button(this, "Abrir ajustes de bateria", Ui.DARK, v -> {
            try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
            catch (Exception e) { toast("Abra Configurações > Bateria manualmente"); }
        }));
        p1.addView(c4);

        LinearLayout c5 = Ui.card(this);
        c5.addView(Ui.text(this, "Desligar tudo", 16, Ui.TEXT, true));
        c5.addView(Ui.desc(this, "Para o loop, remove a bolinha e desativa o serviço, sem desinstalar. Para usar de novo, ative em Acessibilidade."));
        c5.addView(Ui.button(this, "DESLIGAR TUDO", Ui.DANGER, v -> {
            if (ClickService.instance != null) {
                ClickService.instance.shutdown();
                toast("Desligado. Para usar de novo, ative em Acessibilidade.");
                onResume();
            } else toast("O serviço já está desligado");
        }));
        p1.addView(c5);

        // =============== PAGINA 2 (Studio) ===============
        if (studio) {
            p2.addView(Ui.section(this, "Otimização do Fortnite"));
            LinearLayout fo = Ui.card(this);
            fo.addView(Ui.text(this, "Otimização do Fortnite", 17, Ui.TEXT, true));
            fo.addView(Ui.desc(this, "Use as configurações do próprio Fortnite (Configurações > Vídeo). Os nomes podem variar conforme a versão:\n• Modo de desempenho/renderização: ligue se o jogo oferecer.\n• Qualidade geral: Baixa ou Média.\n• Resolução 3D: 70 a 80%.\n• Distância de visão: Perto ou Média.\n• Sombras e efeitos: desligados ou em Baixo.\n• Pós-processamento: Baixo.\n• Texturas: Média, para manter skins, armas e carros bonitos.\n• Limite de FPS: o que seu aparelho segura estável (30 ou 60).\nTambém ajuda fechar apps em segundo plano e deixar o aparelho carregando em sessões longas."));
            fo.addView(Ui.desc(this, "O NexMacro não altera arquivos nem o mapa do jogo (como deixar a grama lisa): isso viola as regras do Fortnite e pode causar banimento."));
            fo.addView(Ui.button(this, "Abrir ajustes de bateria", Ui.DARK, v -> {
                try { startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)); }
                catch (Exception e) { toast("Abra Configurações > Bateria manualmente"); }
            }));
            p2.addView(fo);

            p2.addView(Ui.section(this, "Estúdio"));
            LinearLayout m1 = Ui.card(this);
            m1.addView(Ui.text(this, "Música", 17, Ui.TEXT, true));
            m1.addView(Ui.desc(this, "Toque as músicas do celular em ordem ou aleatório, com disco girando. Também controla o Spotify, YouTube Music e outros que estiverem tocando."));
            m1.addView(Ui.button(this, "Abrir música", Ui.ACCENT, v -> startActivity(new Intent(this, MusicActivity.class))));
            p2.addView(m1);

            LinearLayout m2 = Ui.card(this);
            m2.addView(Ui.text(this, "Desenho", 17, Ui.TEXT, true));
            m2.addView(Ui.desc(this, "Pixel art (16, 32 ou 64) ou desenho livre, com paleta, balde, desfazer e zoom. Salve em PNG na galeria. Na bolinha, \"Desenhar\" rabisca por cima de qualquer tela."));
            m2.addView(Ui.button(this, "Abrir desenho", Ui.ACCENT, v -> startActivity(new Intent(this, DrawActivity.class))));
            p2.addView(m2);

            LinearLayout m3 = Ui.card(this);
            m3.addView(Ui.text(this, "Mapeador de teclas e controle", 17, Ui.TEXT, true));
            m3.addView(Ui.desc(this, "Em breve: botões flutuantes que viram toques quando você aperta uma tecla ou botão de controle, estilo GG Mouse. Vai avisar do risco de ban em cada jogo."));
            p2.addView(m3);

            p2.addView(Ui.section(this, "Personalização"));
            LinearLayout c3 = Ui.card(this);
            c3.addView(Ui.text(this, "Cor dos botões", 16, Ui.TEXT, true));
            LinearLayout colors = new LinearLayout(this);
            colors.setOrientation(LinearLayout.HORIZONTAL);
            for (int i = 0; i < COLORS.length; i++) {
                final int col = COLORS[i];
                View dot = new View(this);
                dot.setBackground(Ui.shape(this, col, 20, Ui.TEXT, col == Ui.ACCENT ? 3 : 0));
                LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(Ui.dp(this, 40), Ui.dp(this, 40));
                dl.setMargins(0, Ui.dp(this, 10), Ui.dp(this, 10), 0);
                dot.setLayoutParams(dl);
                dot.setOnClickListener(v -> { sp.edit().putInt("accent", col).apply(); recreate(); });
                Ui.pressable(dot);
                colors.addView(dot);
            }
            c3.addView(colors);
            c3.addView(Ui.desc(this, "Foto de fundo do app:"));
            c3.addView(Ui.button(this, "Escolher foto", Ui.DARK, v -> {
                Intent in = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                in.addCategory(Intent.CATEGORY_OPENABLE);
                in.setType("image/*");
                startActivityForResult(in, REQ_BG);
            }));
            c3.addView(Ui.button(this, "Remover foto", Ui.DARK, v -> {
                sp.edit().remove("bg").apply();
                recreate();
            }));
            p2.addView(c3);
            addHelp(p2);
        } else {
            addHelp(p1);
        }

        // ---- fundo (cor ou foto) ----
        FrameLayout frame = new FrameLayout(this);
        frame.setBackgroundColor(Ui.BG);
        String bg = studio ? sp.getString("bg", "") : "";
        if (!bg.isEmpty()) {
            try {
                ImageView iv = new ImageView(this);
                iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
                iv.setImageBitmap(decode(Uri.parse(bg)));
                frame.addView(iv, new FrameLayout.LayoutParams(-1, -1));
                View dim = new View(this);
                dim.setBackgroundColor(0xCC05060D);
                frame.addView(dim, new FrameLayout.LayoutParams(-1, -1));
            } catch (Exception e) {
                sp.edit().remove("bg").apply();
            }
        }
        frame.addView(root, new FrameLayout.LayoutParams(-1, -1));
        setContentView(frame);
        refreshTabs();

        animateIn(p1);
        if (studio) animateIn(p2);
    }

    private void addHelp(LinearLayout target) {
        target.addView(Ui.section(this, "Ajuda"));
        LinearLayout c6 = Ui.card(this);
        c6.addView(Ui.text(this, "Assistente e diagnóstico", 16, Ui.TEXT, true));
        c6.addView(Ui.desc(this, "O assistente tira dúvidas de uso. O diagnóstico mostra o que o app leu na tela e decidiu, útil quando algo trava."));
        c6.addView(Ui.button(this, "Conversar com o assistente", Ui.ACCENT,
                v -> startActivity(new Intent(this, AssistantActivity.class))));
        c6.addView(Ui.button(this, "Abrir diagnóstico", Ui.DARK,
                v -> startActivity(new Intent(this, DiagActivity.class))));
        target.addView(c6);

        LinearLayout c7 = Ui.card(this);
        c7.addView(Ui.text(this, "Créditos e suporte", 16, Ui.TEXT, true));
        c7.addView(Ui.desc(this, "Teve algum problema ou quer acompanhar as novidades? Fale pelas redes:"));
        c7.addView(Ui.button(this, "YouTube", 0xFFC4302B, v -> open(YT)));
        c7.addView(Ui.button(this, "TikTok", 0xFF111111, v -> open(TT)));
        target.addView(c7);

        TextView foot = Ui.text(this, "Sem coleta de dados • use por sua conta e risco: jogos podem punir automação.",
                12, Ui.MUTED, false);
        foot.setGravity(Gravity.CENTER);
        foot.setPadding(0, Ui.dp(this, 8), 0, Ui.dp(this, 24));
        target.addView(foot);
    }

    private LinearLayout newPage(LinearLayout pages) {
        ScrollView sv = new ScrollView(this);
        sv.setVerticalScrollBarEnabled(false);
        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(0, 0, 0, Ui.dp(this, 24));
        sv.addView(content);
        pages.addView(sv, new LinearLayout.LayoutParams(pageW, -1));
        return content;
    }

    private void animateIn(LinearLayout content) {
        for (int i = 0; i < content.getChildCount(); i++) {
            View v = content.getChildAt(i);
            v.setAlpha(0f);
            v.setTranslationY(Ui.dp(this, 24));
            v.animate().alpha(1f).translationY(0f).setStartDelay(i * 55L).setDuration(380).start();
        }
    }

    private void goPage(int idx) {
        page = Math.max(0, Math.min(1, idx));
        hs.smoothScrollTo(page * pageW, 0);
        refreshTabs();
    }

    private void refreshTabs() {
        for (int i = 0; i < 2; i++)
            tabs[i].setBackground(Ui.shape(this, i == page ? Ui.ACCENT : Ui.CARD, 12, 0, 0));
    }

    private Bitmap decode(Uri u) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        try (InputStream in = getContentResolver().openInputStream(u)) { BitmapFactory.decodeStream(in, null, o); }
        int sample = 1;
        while (o.outWidth / sample > 1600) sample *= 2;
        BitmapFactory.Options o2 = new BitmapFactory.Options();
        o2.inSampleSize = sample;
        try (InputStream in = getContentResolver().openInputStream(u)) { return BitmapFactory.decodeStream(in, null, o2); }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);
        if (req == REQ_BG && res == RESULT_OK && data != null && data.getData() != null) {
            Uri u = data.getData();
            try { getContentResolver().takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION); }
            catch (Exception ignored) {}
            sp.edit().putString("bg", u.toString()).apply();
            recreate();
        }
    }

    private void open(String url) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))); }
        catch (Exception e) { toast("Não foi possível abrir o link"); }
    }

    private void toast(String s) { Toast.makeText(this, I18n.tr(s), Toast.LENGTH_LONG).show(); }

    @Override
    protected void onResume() {
        super.onResume();
        if (!I18n.lang.equals(shownLang)) { recreate(); return; }
        boolean on = ClickService.instance != null;
        statusTv.setText(I18n.tr(on ? "● Serviço ativo" : "● Serviço desativado"));
        statusTv.setTextColor(on ? Ui.OK : Ui.DANGER);
        JSONObject e = Slots.equipped(this);
        equippedTv.setText(e == null ? I18n.tr("(nenhum)") : e.optString("name"));
        String a = sp.getString("nick_auto", "");
        nickAuto.setText(a.isEmpty() ? I18n.tr("Nick lido automaticamente: (ainda não)")
                : I18n.tr("Nick lido automaticamente: ") + a);
    }

    @Override
    protected void onPause() {
        super.onPause();
        float hs2 = 0f;
        try { hs2 = Math.max(0f, Math.min(10f, Float.parseFloat(hold.getText().toString().trim().replace(',', '.')))); }
        catch (Exception ignored) {}
        sp.edit().putString("nick", nick.getText().toString().trim()).putFloat("holdsec", hs2).apply();
    }
}
