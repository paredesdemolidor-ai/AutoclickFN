package com.autoclick;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SplashActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.BLACK);
        getWindow().setNavigationBarColor(Color.BLACK);
        FrameLayout root = new FrameLayout(this);
        GlowView gv = new GlowView(this);
        gv.setIntensity(1.4f);
        root.addView(gv, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        TextView title = Ui.text(this, getString(R.string.app_name), 36, Ui.TEXT, true);
        title.setLetterSpacing(0.08f);
        title.setShadowLayer(28f, 0, 0, Ui.CYAN);
        TextView sub = Ui.text(this, "Automação inteligente • offline", 14, Ui.MUTED, false);
        sub.setPadding(0, Ui.dp(this, 8), 0, 0);
        col.addView(title);
        col.addView(sub);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));
        setContentView(root);

        title.setAlpha(0f);
        title.setScaleX(0.8f);
        title.setScaleY(0.8f);
        title.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(1000).start();
        sub.setAlpha(0f);
        sub.animate().alpha(1f).setStartDelay(700).setDuration(800).start();

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (isFinishing()) return;
            boolean has = getSharedPreferences("cfg", MODE_PRIVATE).contains("lang");
            startActivity(new Intent(this, has ? MainActivity.class : LanguageActivity.class));
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, 2400);
    }
}
