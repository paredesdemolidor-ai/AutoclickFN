package com.autoclick;

import android.content.ComponentName;
import android.content.Context;
import android.graphics.Bitmap;
import android.media.MediaMetadata;
import android.media.session.MediaController;
import android.media.session.MediaSessionManager;
import android.media.session.PlaybackState;
import android.widget.Toast;

import java.util.List;

/** Controla a musica do app ou de outro app (Spotify, YouTube Music...) que esteja tocando. */
final class MusicCtl {
    static final class Info {
        boolean internal, playing, hasSource;
        String title = "Nada tocando", artist = "", key = "";
        int pos, dur;
        MusicService.Track track;
        Bitmap extArt;
    }

    static MediaController external(Context c) {
        try {
            MediaSessionManager m = (MediaSessionManager) c.getSystemService(Context.MEDIA_SESSION_SERVICE);
            List<MediaController> l = m.getActiveSessions(new ComponentName(c, MediaListener.class));
            MediaController firstOther = null;
            for (MediaController mc : l) {
                if (c.getPackageName().equals(mc.getPackageName())) continue;
                if (firstOther == null) firstOther = mc;
                PlaybackState ps = mc.getPlaybackState();
                if (ps != null && ps.getState() == PlaybackState.STATE_PLAYING) return mc;
            }
            return firstOther;
        } catch (Exception e) {
            return null;
        }
    }

    private static boolean isPlaying(MediaController mc) {
        PlaybackState ps = mc == null ? null : mc.getPlaybackState();
        return ps != null && ps.getState() == PlaybackState.STATE_PLAYING;
    }

    static Info info(Context c) {
        Info i = new Info();
        boolean internalPlaying = MusicService.isPlaying();
        MediaController ext = external(c);
        boolean useInternal = internalPlaying || (!isPlaying(ext) && MusicService.hasTrack());
        MusicService.Track t = MusicService.current();
        if (useInternal && t != null) {
            i.internal = true;
            i.hasSource = true;
            i.track = t;
            i.title = t.title;
            i.artist = t.artist;
            i.playing = internalPlaying;
            i.pos = MusicService.position();
            i.dur = MusicService.duration();
            i.key = "i" + t.id;
            return i;
        }
        if (ext != null) {
            MediaMetadata md = ext.getMetadata();
            if (md != null) {
                String ti = md.getString(MediaMetadata.METADATA_KEY_TITLE);
                String ar = md.getString(MediaMetadata.METADATA_KEY_ARTIST);
                if (ti != null) i.title = ti;
                if (ar != null) i.artist = ar;
                i.extArt = md.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART);
                if (i.extArt == null) i.extArt = md.getBitmap(MediaMetadata.METADATA_KEY_ART);
                i.dur = (int) md.getLong(MediaMetadata.METADATA_KEY_DURATION);
            }
            PlaybackState ps = ext.getPlaybackState();
            if (ps != null) i.pos = (int) ps.getPosition();
            i.playing = isPlaying(ext);
            i.hasSource = true;
            i.key = "e" + i.title + i.artist;
        }
        return i;
    }

    static void toggle(Context c) {
        boolean internalPlaying = MusicService.isPlaying();
        MediaController ext = external(c);
        if (internalPlaying || (!isPlaying(ext) && MusicService.hasTrack() && MusicService.instance != null)) {
            MusicService.toggleNow();
        } else if (ext != null) {
            if (isPlaying(ext)) ext.getTransportControls().pause(); else ext.getTransportControls().play();
        } else {
            Toast.makeText(c, "Nada tocando. Abra Música no NexMacro.", Toast.LENGTH_SHORT).show();
        }
    }

    static void next(Context c) {
        MediaController ext = external(c);
        if (MusicService.isPlaying() || (!isPlaying(ext) && MusicService.hasTrack() && MusicService.instance != null)) MusicService.nextNow();
        else if (ext != null) ext.getTransportControls().skipToNext();
    }

    static void prev(Context c) {
        MediaController ext = external(c);
        if (MusicService.isPlaying() || (!isPlaying(ext) && MusicService.hasTrack() && MusicService.instance != null)) MusicService.prevNow();
        else if (ext != null) ext.getTransportControls().skipToPrevious();
    }

    static void seek(Context c, boolean internal, int ms) {
        if (internal) MusicService.seekTo(ms);
        else {
            MediaController ext = external(c);
            if (ext != null) ext.getTransportControls().seekTo(ms);
        }
    }
}
