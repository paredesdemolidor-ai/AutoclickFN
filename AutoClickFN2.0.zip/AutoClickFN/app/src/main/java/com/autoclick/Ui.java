package com.autoclick;

import android.app.Activity;
import android.content.Context;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.text.InputType;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

final class Ui {
    static int ACCENT = 0xFF7C4DFF;
    static final int BG = 0xFF0F1220, CARD = 0xFF1A1E33, CYAN = 0xFF00E5FF,
            DANGER = 0xFFE5484D, TEXT = 0xFFFFFFFF, MUTED = 0xFFA9B0CF, OK = 0xFF3DDC84, DARK = 0xFF2C3252;

    static int dp(Context c, float v) { return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f); }

    static GradientDrawable shape(Context c, int color, float radiusDp, int strokeColor, float strokeDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        if (strokeDp > 0) g.setStroke(dp(c, strokeDp), strokeColor);
        return g;
    }

    static TextView text(Context c, String s, float sp, int color, boolean bold) {
        TextView t = new TextView(c);
        t.setText(I18n.tr(s));
        t.setTextSize(sp);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    static TextView desc(Context c, String s) {
        TextView t = text(c, s, 13, MUTED, false);
        t.setPadding(0, dp(c, 4), 0, dp(c, 4));
        return t;
    }

    static TextView section(Context c, String s) {
        TextView t = text(c, I18n.tr(s).toUpperCase(), 12, CYAN, true);
        t.setPadding(0, dp(c, 8), 0, dp(c, 8));
        return t;
    }

    static LinearLayout card(Context c) {
        LinearLayout l = new LinearLayout(c);
        l.setOrientation(LinearLayout.VERTICAL);
        int p = dp(c, 16);
        l.setPadding(p, p, p, p);
        l.setBackground(shape(c, CARD, 18, 0, 0));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, 0, 0, dp(c, 12));
        l.setLayoutParams(lp);
        return l;
    }

    /** Cabecalho com botao Voltar. */
    static LinearLayout header(final Activity a, String title) {
        LinearLayout row = new LinearLayout(a);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        TextView back = text(a, "‹ Voltar", 15, TEXT, true);
        int px = dp(a, 14), py = dp(a, 8);
        back.setPadding(px, py, px, py);
        back.setBackground(shape(a, DARK, 12, 0, 0));
        back.setOnClickListener(v -> a.finish());
        pressable(back);
        TextView t = text(a, title, 22, TEXT, true);
        t.setPadding(dp(a, 12), 0, 0, 0);
        row.addView(back);
        row.addView(t);
        row.setPadding(0, 0, 0, dp(a, 8));
        return row;
    }

    /** Efeito de "apertar" nos botoes. */
    static void pressable(View v) {
        v.setOnTouchListener((x, e) -> {
            int a = e.getAction();
            if (a == MotionEvent.ACTION_DOWN) x.animate().scaleX(0.96f).scaleY(0.96f).setDuration(90).start();
            else if (a == MotionEvent.ACTION_UP || a == MotionEvent.ACTION_CANCEL) x.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
            return false;
        });
    }

    static Button button(Context c, String s, int color, View.OnClickListener cl) {
        Button b = new Button(c);
        b.setText(I18n.tr(s));
        b.setAllCaps(false);
        b.setTextColor(TEXT);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setBackground(shape(c, color, 12, 0, 0));
        b.setOnClickListener(cl);
        pressable(b);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(c, 46));
        lp.setMargins(0, dp(c, 8), 0, 0);
        b.setLayoutParams(lp);
        return b;
    }

    static EditText field(Context c, String hint, boolean multi) {
        EditText e = new EditText(c);
        e.setHint(I18n.tr(hint));
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(14);
        int pd = dp(c, 12);
        e.setPadding(pd, pd, pd, pd);
        e.setBackground(shape(c, BG, 12, DARK, 1));
        if (multi) {
            e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            e.setMinLines(3);
            e.setGravity(Gravity.TOP);
        } else {
            e.setSingleLine(true);
        }
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, dp(c, 8), 0, 0);
        e.setLayoutParams(lp);
        return e;
    }
}
