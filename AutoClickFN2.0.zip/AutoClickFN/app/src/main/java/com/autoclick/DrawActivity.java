package com.autoclick;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ContentValues;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.io.OutputStream;
import java.util.ArrayList;
import java.util.List;

public class DrawActivity extends Activity {
    private static final int[] PALETTE = {0xFF000000, 0xFFFFFFFF, 0xFF8A8F98, 0xFFE5484D, 0xFFFF9100, 0xFFFFEB3B,
            0xFF3DDC84, 0xFF00E5FF, 0xFF2979FF, 0xFF7C4DFF, 0xFFFF4081, 0xFF795548, 0xFFFFCC99, 0xFF1B5E20, 0xFF0D1B4A, 0xFF4A148C};
    private static final int[] SIZES = {16, 32, 64, 0};

    private DrawView draw;
    private int mode = 1, color = 0xFF000000, tool = DrawView.PEN;
    private final TextView[] modeChips = new TextView[4];
    private final TextView[] toolChips = new TextView[4];
    private TextView gridChip;
    private final List<View> swatches = new ArrayList<>();
    private SeekBar brush;
    private TextView brushLabel;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        int p = Ui.dp(this, 12);
        root.setPadding(p, Ui.dp(this, 20), p, p);
        root.addView(Ui.header(this, "Desenho"));

        // modos + salvar
        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.HORIZONTAL);
        String[] mn = {"Pixel 16", "Pixel 32", "Pixel 64", "Livre"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            modeChips[i] = chip(mn[i], v -> askNew(idx));
            modes.addView(modeChips[i]);
        }
        modes.addView(chip("Salvar PNG", v -> save()));
        root.addView(scroll(modes));

        draw = new DrawView(this);
        draw.setPickListener(c -> setColor(c));
        draw.setLayoutParams(new LinearLayout.LayoutParams(-1, 0, 1f));
        root.addView(draw);

        // ferramentas
        LinearLayout tools = new LinearLayout(this);
        tools.setOrientation(LinearLayout.HORIZONTAL);
        String[] tn = {"Lápis", "Borracha", "Balde", "Conta-gotas"};
        for (int i = 0; i < 4; i++) {
            final int idx = i;
            toolChips[i] = chip(tn[i], v -> setTool(idx));
            tools.addView(toolChips[i]);
        }
        tools.addView(chip("Desfazer", v -> draw.undo()));
        tools.addView(chip("Refazer", v -> draw.redo()));
        gridChip = chip("Grade", v -> { draw.setGrid(!draw.grid()); refresh(); });
        tools.addView(gridChip);
        tools.addView(chip("Limpar", v -> new AlertDialog.Builder(this)
                .setTitle("Limpar o desenho?")
                .setPositiveButton("Limpar", (d, w) -> draw.clearAll())
                .setNegativeButton("Cancelar", null).show()));
        root.addView(scroll(tools));

        // pincel
        LinearLayout br = new LinearLayout(this);
        br.setOrientation(LinearLayout.HORIZONTAL);
        br.setGravity(android.view.Gravity.CENTER_VERTICAL);
        brushLabel = Ui.text(this, "Pincel 1", 12, Ui.MUTED, false);
        brush = new SeekBar(this);
        brush.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
        brush.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int pr, boolean u) {
                draw.setBrush(pr + 1);
                brushLabel.setText("Pincel " + (pr + 1));
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        });
        br.addView(brushLabel);
        br.addView(brush);
        root.addView(br);

        // paleta
        LinearLayout pal = new LinearLayout(this);
        pal.setOrientation(LinearLayout.HORIZONTAL);
        for (final int col : PALETTE) {
            View s = new View(this);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(Ui.dp(this, 34), Ui.dp(this, 34));
            lp.setMargins(0, Ui.dp(this, 6), Ui.dp(this, 6), Ui.dp(this, 2));
            s.setLayoutParams(lp);
            s.setTag(col);
            s.setOnClickListener(v -> setColor(col));
            swatches.add(s);
            pal.addView(s);
        }
        pal.addView(chip("Mais cores", v -> customColor()));
        root.addView(scroll(pal));

        setContentView(root);
        applyMode(1);
    }

    private HorizontalScrollView scroll(LinearLayout row) {
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        hs.addView(row);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.setMargins(0, Ui.dp(this, 6), 0, 0);
        hs.setLayoutParams(lp);
        return hs;
    }

    private TextView chip(String t, View.OnClickListener l) {
        TextView v = Ui.text(this, t, 13, Ui.TEXT, true);
        v.setPadding(Ui.dp(this, 14), Ui.dp(this, 10), Ui.dp(this, 14), Ui.dp(this, 10));
        v.setBackground(Ui.shape(this, Ui.DARK, 12, 0, 0));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, 0, Ui.dp(this, 6), 0);
        v.setLayoutParams(lp);
        v.setOnClickListener(l);
        Ui.pressable(v);
        return v;
    }

    private void askNew(final int idx) {
        new AlertDialog.Builder(this)
                .setTitle("Novo desenho?")
                .setMessage("O desenho atual será perdido. Salve em PNG antes se quiser guardar.")
                .setPositiveButton("Novo", (d, w) -> applyMode(idx))
                .setNegativeButton("Cancelar", null).show();
    }

    private void applyMode(int idx) {
        mode = idx;
        if (SIZES[idx] > 0) { draw.newCanvas(true, SIZES[idx]); brush.setMax(7); brush.setProgress(0); }
        else { draw.newCanvas(false, 1024); brush.setMax(59); brush.setProgress(7); }
        draw.setColor(color);
        setTool(DrawView.PEN);
        refresh();
    }

    private void setTool(int t) {
        tool = t;
        draw.setTool(t);
        refresh();
    }

    private void setColor(int c) {
        color = c;
        draw.setColor(c);
        if (tool == DrawView.PICK) setTool(DrawView.PEN);
        refresh();
    }

    private void refresh() {
        for (int i = 0; i < 4; i++) {
            modeChips[i].setBackground(Ui.shape(this, i == mode ? Ui.ACCENT : Ui.DARK, 12, 0, 0));
            toolChips[i].setBackground(Ui.shape(this, i == tool ? Ui.ACCENT : Ui.DARK, 12, 0, 0));
        }
        gridChip.setBackground(Ui.shape(this, draw.grid() ? Ui.ACCENT : Ui.DARK, 12, 0, 0));
        for (View s : swatches) {
            int col = (Integer) s.getTag();
            s.setBackground(Ui.shape(this, col, 8, Ui.TEXT, col == color ? 3 : 1));
        }
    }

    private void customColor() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pd = Ui.dp(this, 16);
        box.setPadding(pd, pd, pd, pd);
        final View prev = new View(this);
        prev.setLayoutParams(new LinearLayout.LayoutParams(-1, Ui.dp(this, 40)));
        prev.setBackgroundColor(color);
        box.addView(prev);
        final SeekBar[] sk = new SeekBar[3];
        int[] init = {Color.red(color), Color.green(color), Color.blue(color)};
        String[] names = {"Vermelho", "Verde", "Azul"};
        SeekBar.OnSeekBarChangeListener l = new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar sb, int pr, boolean u) {
                prev.setBackgroundColor(Color.rgb(sk[0].getProgress(), sk[1].getProgress(), sk[2].getProgress()));
            }
            @Override public void onStartTrackingTouch(SeekBar sb) {}
            @Override public void onStopTrackingTouch(SeekBar sb) {}
        };
        for (int i = 0; i < 3; i++) {
            TextView lb = new TextView(this);
            lb.setText(names[i]);
            box.addView(lb);
            sk[i] = new SeekBar(this);
            sk[i].setMax(255);
            sk[i].setProgress(init[i]);
            sk[i].setOnSeekBarChangeListener(l);
            box.addView(sk[i]);
        }
        new AlertDialog.Builder(this)
                .setTitle("Cor personalizada")
                .setView(box)
                .setPositiveButton("Usar", (d, w) -> setColor(Color.rgb(sk[0].getProgress(), sk[1].getProgress(), sk[2].getProgress())))
                .setNegativeButton("Cancelar", null).show();
    }

    private void save() {
        try {
            Bitmap out = draw.exportBitmap();
            ContentValues v = new ContentValues();
            v.put(MediaStore.Images.Media.DISPLAY_NAME, "nexmacro_" + System.currentTimeMillis() + ".png");
            v.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
            v.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/NexMacro");
            Uri u = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, v);
            if (u == null) throw new Exception("sem destino");
            try (OutputStream os = getContentResolver().openOutputStream(u)) {
                out.compress(Bitmap.CompressFormat.PNG, 100, os);
            }
            Toast.makeText(this, "Salvo em Imagens/NexMacro", Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Não foi possível salvar", Toast.LENGTH_LONG).show();
        }
    }
}
