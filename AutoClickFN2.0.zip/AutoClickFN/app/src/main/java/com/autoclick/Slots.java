package com.autoclick;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** Ate 5 auto clicks equipaveis. Equipar copia os ajustes do slot para as chaves que o servico le. */
final class Slots {
    static final int MAX = 5;

    static SharedPreferences prefs(Context c) { return c.getSharedPreferences("cfg", Context.MODE_PRIVATE); }

    static String kindLabel(String kind) {
        return "xc".equals(kind) ? "xCloud (Xbox)" : "custom".equals(kind) ? "Macro livre" : "Fortnite mobile";
    }

    static JSONObject template(String kind, boolean orig) {
        JSONObject o = new JSONObject();
        try {
            o.put("id", Long.toString(System.nanoTime()));
            o.put("name", orig ? ("xc".equals(kind) ? "xCloud Fortnite" : "Fortnite mobile")
                    : "custom".equals(kind) ? "Novo macro livre" : "Novo auto click");
            o.put("kind", kind);
            o.put("extra", "");
            o.put("maxmin", 30);
            o.put("wipe", true);
            o.put("speed", 1);
            o.put("notes", "");
            o.put("orig", orig);
            o.put("endact", "lobby");
            o.put("game", "");
            o.put("rules", "");
            o.put("afk", false);
            o.put("busy", false);
        } catch (Exception ignored) {}
        return o;
    }

    static List<JSONObject> load(Context c) {
        List<JSONObject> out = new ArrayList<>();
        try {
            JSONArray a = new JSONArray(prefs(c).getString("slots", "[]"));
            for (int i = 0; i < a.length(); i++) out.add(a.getJSONObject(i));
        } catch (Exception ignored) {}
        return out;
    }

    static void save(Context c, List<JSONObject> l) {
        JSONArray a = new JSONArray();
        for (JSONObject o : l) a.put(o);
        prefs(c).edit().putString("slots", a.toString()).apply();
    }

    static void ensure(Context c) {
        if (prefs(c).contains("slots")) return;
        List<JSONObject> l = new ArrayList<>();
        l.add(template("fn", true));
        l.add(template("xc", true));
        save(c, l);
        equip(c, l.get(0));
    }

    static String equippedId(Context c) { return prefs(c).getString("equipped", ""); }

    static JSONObject equipped(Context c) {
        List<JSONObject> l = load(c);
        String id = equippedId(c);
        for (JSONObject o : l) if (o.optString("id").equals(id)) return o;
        return l.isEmpty() ? null : l.get(0);
    }

    static void equip(Context c, JSONObject o) {
        String kind = o.optString("kind", "fn");
        prefs(c).edit()
                .putString("equipped", o.optString("id"))
                .putString("mode", kind)
                .putString("extra_" + kind, o.optString("extra", ""))
                .putInt("maxmin", o.optInt("maxmin", 30))
                .putBoolean("wipe", o.optBoolean("wipe", true))
                .putInt("speed", o.optInt("speed", 1))
                .putString("endact", o.optString("endact", "lobby"))
                .putString("rules", o.optString("rules", ""))
                .putBoolean("afk", o.optBoolean("afk", false))
                .putBoolean("busy", o.optBoolean("busy", false))
                .apply();
    }

    /** Equipa o proximo da lista e devolve o nome. */
    static String next(Context c) {
        List<JSONObject> l = load(c);
        if (l.isEmpty()) return null;
        String id = equippedId(c);
        int idx = -1;
        for (int i = 0; i < l.size(); i++) if (l.get(i).optString("id").equals(id)) idx = i;
        JSONObject n = l.get((idx + 1) % l.size());
        equip(c, n);
        return n.optString("name");
    }

    static boolean add(Context c, String kind, boolean orig) { return addJson(c, template(kind, orig)); }

    static boolean addJson(Context c, JSONObject o) {
        List<JSONObject> l = load(c);
        if (l.size() >= MAX) return false;
        l.add(o);
        save(c, l);
        if (l.size() == 1) equip(c, o);
        return true;
    }

    static void remove(Context c, String id) {
        List<JSONObject> l = load(c);
        List<JSONObject> out = new ArrayList<>();
        for (JSONObject o : l) if (!o.optString("id").equals(id)) out.add(o);
        save(c, out);
        if (id.equals(equippedId(c))) {
            if (!out.isEmpty()) equip(c, out.get(0));
            else prefs(c).edit().remove("equipped").apply();
        }
    }

    /** Volta os dois originais ao padrao (recria se foram excluidos). Devolve false se faltou espaco. */
    static boolean restoreOriginals(Context c) {
        boolean ok = true;
        for (String kind : new String[]{"fn", "xc"}) {
            List<JSONObject> l = load(c);
            int at = -1;
            for (int i = 0; i < l.size(); i++)
                if (l.get(i).optBoolean("orig") && kind.equals(l.get(i).optString("kind"))) at = i;
            if (at >= 0) {
                JSONObject t = template(kind, true);
                try { t.put("id", l.get(at).optString("id")); } catch (Exception ignored) {}
                l.set(at, t);
                save(c, l);
                if (t.optString("id").equals(equippedId(c))) equip(c, t);
            } else if (!add(c, kind, true)) {
                ok = false;
            }
        }
        return ok;
    }
}
