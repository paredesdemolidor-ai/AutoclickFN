package com.autoclick;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Escolha de idioma: define o idioma do app e como ele le os textos do jogo. */
public class LanguageActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setBackgroundColor(Ui.BG);
        int p = Ui.dp(this, 24);
        root.setPadding(p, p, p, p);

        TextView title = new TextView(this);
        title.setText("Escolha seu idioma\nChoose your language\nElige tu idioma");
        title.setTextColor(Ui.TEXT);
        title.setTextSize(22);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        root.addView(title);

        TextView sub = new TextView(this);
        sub.setText("O idioma também define como o app lê os textos do jogo.\n"
                + "The language also sets how the app reads the game's text.\n"
                + "El idioma también define cómo la app lee los textos del juego.");
        sub.setTextColor(Ui.MUTED);
        sub.setTextSize(12);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 20));
        root.addView(sub);

        String[] names = {"Português (Brasil)", "English", "Español"};
        final String[] codes = {"pt", "en", "es"};
        for (int i = 0; i < 3; i++) {
            final String code = codes[i];
            root.addView(Ui.button(this, names[i], Ui.ACCENT, v -> pick(code)));
        }
        setContentView(root);
    }

    private void pick(String code) {
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("lang", code).apply();
        I18n.lang = code;
        if (!getIntent().getBooleanExtra("settings", false)) {
            startActivity(new Intent(this, MainActivity.class));
        }
        finish();
    }
}
