package com.autoclick;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;

/** Tela de desenho: pixel art (grade) ou desenho livre. Zoom e arrastar com dois dedos. */
public class DrawView extends View {
    static final int PEN = 0, ERASER = 1, FILL = 2, PICK = 3;

    interface PickListener { void onPick(int color); }

    private Bitmap bmp;
    private Canvas cv;
    private boolean pixel = true, grid = true, needFit = true, stroking = false, multi = false;
    private int tool = PEN, color = 0xFF000000, brush = 1;
    private float fitScale = 1f, lastX, lastY, lastDist;
    private final float[] lastMid = new float[2];
    private final Matrix m = new Matrix(), inv = new Matrix();
    private final Paint bmpPaint = new Paint(), gridPaint = new Paint(), cellPaint = new Paint(), strokePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final ArrayList<Bitmap> undo = new ArrayList<>(), redo = new ArrayList<>();
    private PickListener pickListener;

    public DrawView(Context c) {
        super(c);
        gridPaint.setColor(0x33FFFFFF);
        strokePaint.setStrokeCap(Paint.Cap.ROUND);
        strokePaint.setStyle(Paint.Style.FILL_AND_STROKE);
        newCanvas(true, 32);
    }

    void setPickListener(PickListener l) { pickListener = l; }
    void setTool(int t) { tool = t; }
    void setColor(int c) { color = c; }
    void setBrush(int b) { brush = Math.max(1, b); }
    void setGrid(boolean g) { grid = g; invalidate(); }
    boolean isPixel() { return pixel; }
    boolean grid() { return grid; }

    void newCanvas(boolean pixelMode, int size) {
        pixel = pixelMode;
        bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
        bmp.eraseColor(pixel ? Color.TRANSPARENT : Color.WHITE);
        cv = new Canvas(bmp);
        undo.clear();
        redo.clear();
        brush = pixel ? 1 : 8;
        needFit = true;
        fit();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        if (needFit) fit();
    }

    private void fit() {
        if (bmp == null || getWidth() == 0 || getHeight() == 0) { needFit = true; return; }
        needFit = false;
        float s = Math.min(getWidth(), getHeight()) / (float) bmp.getWidth() * 0.96f;
        fitScale = s;
        m.reset();
        m.postScale(s, s);
        m.postTranslate((getWidth() - bmp.getWidth() * s) / 2f, (getHeight() - bmp.getHeight() * s) / 2f);
        invalidate();
    }

    private float scale() {
        float[] v = new float[9];
        m.getValues(v);
        return v[Matrix.MSCALE_X];
    }

    @Override
    protected void onDraw(Canvas c) {
        c.drawColor(0xFF0B0D18);
        if (bmp == null) return;
        int w = bmp.getWidth(), h = bmp.getHeight();
        c.save();
        c.concat(m);
        if (pixel) {
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    cellPaint.setColor(((x + y) & 1) == 0 ? 0xFF2A2E48 : 0xFF353A5A);
                    c.drawRect(x, y, x + 1, y + 1, cellPaint);
                }
            }
        }
        bmpPaint.setFilterBitmap(!pixel);
        c.drawBitmap(bmp, 0, 0, bmpPaint);
        if (pixel && grid && scale() >= 6f) {
            gridPaint.setStrokeWidth(1f / scale());
            for (int i = 0; i <= w; i++) c.drawLine(i, 0, i, h, gridPaint);
            for (int j = 0; j <= h; j++) c.drawLine(0, j, w, j, gridPaint);
        }
        c.restore();
    }

    private float[] toImg(float x, float y) {
        float[] pt = {x, y};
        m.invert(inv);
        inv.mapPoints(pt);
        return pt;
    }

    private float dist(MotionEvent e) {
        float dx = e.getX(0) - e.getX(1), dy = e.getY(0) - e.getY(1);
        return (float) Math.sqrt(dx * dx + dy * dy);
    }

    private void mid(MotionEvent e, float[] out) {
        out[0] = (e.getX(0) + e.getX(1)) / 2f;
        out[1] = (e.getY(0) + e.getY(1)) / 2f;
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN: {
                multi = false;
                float[] p = toImg(e.getX(), e.getY());
                begin(p[0], p[1]);
                return true;
            }
            case MotionEvent.ACTION_POINTER_DOWN:
                if (e.getPointerCount() == 2) {
                    multi = true;
                    stroking = false;
                    lastDist = dist(e);
                    mid(e, lastMid);
                }
                return true;
            case MotionEvent.ACTION_MOVE:
                if (multi && e.getPointerCount() >= 2) {
                    float d = dist(e);
                    float[] mm = new float[2];
                    mid(e, mm);
                    if (lastDist > 0) {
                        float s = d / lastDist, cur = scale();
                        float min = fitScale * 0.4f, max = fitScale * (pixel ? 40f : 8f);
                        if (cur * s < min || cur * s > max) s = 1f;
                        m.postScale(s, s, mm[0], mm[1]);
                        m.postTranslate(mm[0] - lastMid[0], mm[1] - lastMid[1]);
                    }
                    lastDist = d;
                    lastMid[0] = mm[0];
                    lastMid[1] = mm[1];
                    invalidate();
                } else if (!multi && stroking) {
                    float[] p = toImg(e.getX(), e.getY());
                    paint(lastX, lastY, p[0], p[1]);
                    lastX = p[0];
                    lastY = p[1];
                }
                return true;
            case MotionEvent.ACTION_POINTER_UP:
                return true;
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL:
                stroking = false;
                multi = false;
                return true;
        }
        return true;
    }

    private void begin(float x, float y) {
        boolean inside = x >= 0 && y >= 0 && x < bmp.getWidth() && y < bmp.getHeight();
        if (tool == PICK) {
            if (inside) {
                int c = bmp.getPixel((int) x, (int) y);
                if (Color.alpha(c) == 0) c = Color.WHITE;
                color = c;
                if (pickListener != null) pickListener.onPick(c);
            }
            return;
        }
        if (tool == FILL) {
            if (inside) { pushUndo(); fill((int) x, (int) y); invalidate(); }
            return;
        }
        pushUndo();
        stroking = true;
        lastX = x;
        lastY = y;
        paint(x, y, x, y);
    }

    private void paint(float x0, float y0, float x1, float y1) {
        int col = tool == ERASER ? (pixel ? Color.TRANSPARENT : Color.WHITE) : color;
        if (pixel) {
            int ax = (int) Math.floor(x0), ay = (int) Math.floor(y0), bx = (int) Math.floor(x1), by = (int) Math.floor(y1);
            int dx = Math.abs(bx - ax), dy = Math.abs(by - ay), sx = ax < bx ? 1 : -1, sy = ay < by ? 1 : -1, err = dx - dy;
            while (true) {
                stamp(ax, ay, col);
                if (ax == bx && ay == by) break;
                int e2 = 2 * err;
                if (e2 > -dy) { err -= dy; ax += sx; }
                if (e2 < dx) { err += dx; ay += sy; }
            }
        } else {
            strokePaint.setColor(col);
            strokePaint.setStrokeWidth(brush);
            if (x0 == x1 && y0 == y1) cv.drawCircle(x0, y0, brush / 2f, strokePaint);
            else cv.drawLine(x0, y0, x1, y1, strokePaint);
        }
        invalidate();
    }

    private void stamp(int cx, int cy, int col) {
        int half = brush / 2;
        for (int oy = 0; oy < brush; oy++) {
            for (int ox = 0; ox < brush; ox++) {
                int px = cx - half + ox, py = cy - half + oy;
                if (px >= 0 && py >= 0 && px < bmp.getWidth() && py < bmp.getHeight()) bmp.setPixel(px, py, col);
            }
        }
    }

    private void fill(int sx, int sy) {
        int w = bmp.getWidth(), h = bmp.getHeight();
        int[] px = new int[w * h];
        bmp.getPixels(px, 0, w, 0, 0, w, h);
        int target = px[sy * w + sx], repl = color;
        if (target == repl) return;
        int[] q = new int[w * h];
        int head = 0, tail = 0;
        px[sy * w + sx] = repl;
        q[tail++] = sy * w + sx;
        while (head < tail) {
            int i = q[head++], x = i % w, y = i / w;
            if (x > 0 && px[i - 1] == target) { px[i - 1] = repl; q[tail++] = i - 1; }
            if (x < w - 1 && px[i + 1] == target) { px[i + 1] = repl; q[tail++] = i + 1; }
            if (y > 0 && px[i - w] == target) { px[i - w] = repl; q[tail++] = i - w; }
            if (y < h - 1 && px[i + w] == target) { px[i + w] = repl; q[tail++] = i + w; }
        }
        bmp.setPixels(px, 0, w, 0, 0, w, h);
    }

    private void pushUndo() {
        undo.add(bmp.copy(Bitmap.Config.ARGB_8888, false));
        if (undo.size() > (pixel ? 60 : 12)) undo.remove(0);
        redo.clear();
    }

    private void restore(Bitmap snap) {
        bmp = snap.copy(Bitmap.Config.ARGB_8888, true);
        cv = new Canvas(bmp);
        invalidate();
    }

    void undo() {
        if (undo.isEmpty()) return;
        redo.add(bmp.copy(Bitmap.Config.ARGB_8888, false));
        restore(undo.remove(undo.size() - 1));
    }

    void redo() {
        if (redo.isEmpty()) return;
        undo.add(bmp.copy(Bitmap.Config.ARGB_8888, false));
        restore(redo.remove(redo.size() - 1));
    }

    void clearAll() {
        pushUndo();
        bmp.eraseColor(pixel ? Color.TRANSPARENT : Color.WHITE);
        invalidate();
    }

    /** Bitmap para salvar: no pixel art amplia sem borrar. */
    Bitmap exportBitmap() {
        if (!pixel) return bmp;
        int k = Math.max(1, 1024 / bmp.getWidth());
        return Bitmap.createScaledBitmap(bmp, bmp.getWidth() * k, bmp.getHeight() * k, false);
    }
}
